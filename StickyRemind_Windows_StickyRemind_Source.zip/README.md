StickyRemind (Windows Desktop)

What it is
- A small always-on-top sticky-style reminder window for Windows.
- Local-first: data stored in a local SQLite database under AppData.
- Reminders support Once, Daily, Weekly (mask), Interval (every N days).
- Manual snooze from UI (10m / 60m) does not drift the recurrence series.
- Missed reminders on sleep/off are handled by CatchUpMode:
  - coalesce (default): show one summary toast, advance the schedule
  - fireall: fire all missed
  - skip: advance silently

Build and run (Windows)
1) Install .NET SDK 8
2) From the repo root:
   dotnet restore
   dotnet build -c Release
3) Run:
   dotnet run --project src/StickyRemind.App/StickyRemind.App.csproj

Data location
- %AppData%\StickyRemind\stickyremind.db

Notes
- The app hides to tray when you close the window.
- Use tray menu to exit.

License
- MIT
