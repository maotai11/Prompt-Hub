using StickyRemind.Domain.Entities;

namespace StickyRemind.Domain.Engine;

public sealed class RecurrenceEngine
{
    public DateTimeOffset ComputeFirstNext(ReminderRule rule)
    {
        return rule.Type switch
        {
            ReminderType.None => DateTimeOffset.MaxValue,
            ReminderType.Once => rule.StartLocal,
            ReminderType.Daily => AlignToDaily(rule.StartLocal, rule.TimeOfDayLocal ?? rule.StartLocal.TimeOfDay),
            ReminderType.Weekly => AlignToWeekly(rule.StartLocal, rule.TimeOfDayLocal ?? rule.StartLocal.TimeOfDay, rule.WeeklyMask ?? 0),
            ReminderType.Interval => AlignToInterval(rule.StartLocal, rule.TimeOfDayLocal ?? rule.StartLocal.TimeOfDay, rule.IntervalDays ?? 1),
            _ => rule.StartLocal
        };
    }

    public DateTimeOffset ComputeNextFromCursor(DateTimeOffset seriesCursorLocal, ReminderRule rule)
    {
        // seriesCursorLocal is the last "rule-aligned" occurrence in local time.
        return rule.Type switch
        {
            ReminderType.None => DateTimeOffset.MaxValue,
            ReminderType.Once => DateTimeOffset.MaxValue, // once ends after fire
            ReminderType.Daily => seriesCursorLocal.Date.Add(rule.TimeOfDayLocal ?? seriesCursorLocal.TimeOfDay).AddDays(1),
            ReminderType.Weekly => NextWeekly(seriesCursorLocal, rule.TimeOfDayLocal ?? seriesCursorLocal.TimeOfDay, rule.WeeklyMask ?? 0),
            ReminderType.Interval => seriesCursorLocal.Date.Add(rule.TimeOfDayLocal ?? seriesCursorLocal.TimeOfDay).AddDays(rule.IntervalDays ?? 1),
            _ => DateTimeOffset.MaxValue
        };
    }

    public IEnumerable<DateTimeOffset> ComputeMissedOccurrences(DateTimeOffset nextLocal, DateTimeOffset nowLocal, ReminderRule rule, int max = 64)
    {
        // Returns the sequence of rule-aligned occurrences that are <= nowLocal, starting from nextLocal.
        // Used for catch-up.
        var list = new List<DateTimeOffset>();
        var cursor = nextLocal;
        int i = 0;
        while (cursor <= nowLocal && i < max)
        {
            list.Add(cursor);
            i++;
            cursor = rule.Type == ReminderType.Once ? DateTimeOffset.MaxValue : ComputeNextFromCursor(cursor, rule);
            if (cursor == DateTimeOffset.MaxValue) break;
        }
        return list;
    }

    private static DateTimeOffset AlignToDaily(DateTimeOffset startLocal, TimeSpan timeOfDay)
    {
        var candidate = startLocal.Date.Add(timeOfDay);
        if (candidate < startLocal) candidate = candidate.AddDays(1);
        return candidate;
    }

    private static DateTimeOffset AlignToInterval(DateTimeOffset startLocal, TimeSpan timeOfDay, int intervalDays)
    {
        intervalDays = Math.Max(1, intervalDays);
        var candidate = startLocal.Date.Add(timeOfDay);
        if (candidate < startLocal) candidate = candidate.AddDays(intervalDays);
        return candidate;
    }

    private static DateTimeOffset AlignToWeekly(DateTimeOffset startLocal, TimeSpan timeOfDay, int weeklyMask)
    {
        if (weeklyMask == 0)
        {
            // default: same weekday as start
            weeklyMask = 1 << (((int)startLocal.DayOfWeek + 6) % 7); // convert Sunday=0 to bit6, Monday=1->bit0
        }

        var baseDay = startLocal.Date.Add(timeOfDay);
        // find earliest day >= startLocal matching mask
        for (int d = 0; d < 7; d++)
        {
            var candidate = baseDay.AddDays(d);
            if (candidate < startLocal) continue;
            if (IsDaySelected(candidate, weeklyMask)) return candidate;
        }
        // fallback next week
        for (int d = 7; d < 14; d++)
        {
            var candidate = baseDay.AddDays(d);
            if (IsDaySelected(candidate, weeklyMask)) return candidate;
        }
        return baseDay.AddDays(7);
    }

    private static DateTimeOffset NextWeekly(DateTimeOffset lastLocal, TimeSpan timeOfDay, int weeklyMask)
    {
        if (weeklyMask == 0) weeklyMask = 1 << (((int)lastLocal.DayOfWeek + 6) % 7);
        var start = lastLocal.Date.Add(timeOfDay).AddDays(1);
        for (int d = 0; d < 14; d++)
        {
            var candidate = start.AddDays(d);
            if (IsDaySelected(candidate, weeklyMask)) return candidate;
        }
        return start.AddDays(7);
    }

    private static bool IsDaySelected(DateTimeOffset localDateTime, int mask)
    {
        // Monday bit0 ... Sunday bit6
        int bit = ((int)localDateTime.DayOfWeek + 6) % 7;
        return ((mask >> bit) & 1) == 1;
    }
}
