namespace StickyRemind.Domain.Policy;

public enum CatchUpMode
{
    Coalesce = 0,
    FireAll = 1,
    Skip = 2
}
