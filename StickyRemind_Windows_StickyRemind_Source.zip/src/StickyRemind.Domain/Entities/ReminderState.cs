namespace StickyRemind.Domain.Entities;

public enum ReminderStatus
{
    Active = 0,
    Paused = 1,
    Completed = 2
}

public sealed class ReminderState
{
    public string RuleId { get; set; } = string.Empty;

    public DateTimeOffset NextOccurrenceLocal { get; set; }
    public long NextOccurrenceUtcTicks { get; set; }

    // Cursor anchors the recurrence series to prevent drift when user manually adjusts next occurrence.
    public DateTimeOffset SeriesCursorLocal { get; set; }
    public long SeriesCursorUtcTicks { get; set; }

    public DateTimeOffset? LastFiredLocal { get; set; }
    public long? LastFiredUtcTicks { get; set; }

    public ReminderStatus Status { get; set; } = ReminderStatus.Active;

    // optional global snooze per rule
    public long? SnoozeUntilUtcTicks { get; set; }
}
