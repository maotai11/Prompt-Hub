namespace StickyRemind.Domain.Entities;

public sealed class TaskItem
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string Content { get; set; } = string.Empty;
    public bool IsDone { get; set; }

    // Local time is required by spec. We store both local ISO and UTC ticks for computations.
    public DateTimeOffset CreatedAtLocal { get; init; } = DateTimeOffset.Now;
    public long CreatedAtUtcTicks { get; init; } = DateTimeOffset.UtcNow.UtcTicks;

    public DateTimeOffset? DoneAtLocal { get; set; }
    public long UpdatedAtUtcTicks { get; set; } = DateTimeOffset.UtcNow.UtcTicks;
}
