namespace StickyRemind.Domain.Entities;

public sealed class ReminderAdjustment
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string RuleId { get; set; } = string.Empty;

    public long AdjustedAtUtcTicks { get; set; } = DateTimeOffset.UtcNow.UtcTicks;

    public long OldNextUtcTicks { get; set; }
    public long NewNextUtcTicks { get; set; }

    public string Reason { get; set; } = "manual";
    public string? Note { get; set; }
}
