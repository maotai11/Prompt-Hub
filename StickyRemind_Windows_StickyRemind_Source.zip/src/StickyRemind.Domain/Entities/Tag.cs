namespace StickyRemind.Domain.Entities;

public sealed class Tag
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = string.Empty;
    public string? Color { get; set; }  // optional hex string
    public int SortOrder { get; set; }
    public bool IsArchived { get; set; }
}
