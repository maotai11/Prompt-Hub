namespace StickyRemind.Domain.Entities;

public sealed class OccurrenceLog
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N"); // occurrenceId
    public string RuleId { get; set; } = string.Empty;
    public long PlannedUtcTicks { get; set; }
    public long? FiredUtcTicks { get; set; }
    public string Result { get; set; } = "fired"; // fired|skipped|coalesced
    public string? MetaJson { get; set; }
}
