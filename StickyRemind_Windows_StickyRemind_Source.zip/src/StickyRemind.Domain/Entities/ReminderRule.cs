namespace StickyRemind.Domain.Entities;

public enum ReminderType
{
    None = 0,
    Once = 1,
    Daily = 2,
    Weekly = 3,
    Interval = 4
}

/// <summary>
/// Recurrence rule. Local time + timezone id are stored to keep user intent stable.
/// </summary>
public sealed class ReminderRule
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string TaskId { get; set; } = string.Empty;

    public ReminderType Type { get; set; } = ReminderType.None;

    // When the series starts (local). For Once, this is the trigger time.
    public DateTimeOffset StartLocal { get; set; } = DateTimeOffset.Now;

    // For daily/weekly/interval: time-of-day local.
    public TimeSpan? TimeOfDayLocal { get; set; }

    // For interval: every N days
    public int? IntervalDays { get; set; }

    // For weekly: bitmask Mon..Sun (bit0=Mon ... bit6=Sun)
    public int? WeeklyMask { get; set; }

    // optional end
    public DateTimeOffset? EndLocal { get; set; }

    // Windows timezone id (e.g., "Taipei Standard Time") by default current system.
    public string TimeZoneId { get; set; } = TimeZoneInfo.Local.Id;

    public long CreatedAtUtcTicks { get; set; } = DateTimeOffset.UtcNow.UtcTicks;
}
