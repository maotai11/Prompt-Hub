using StickyRemind.App.Mvvm;

namespace StickyRemind.App;

public sealed class TaskRowViewModel : ObservableObject
{
    public string Id { get; }
    public string? ReminderRuleId { get; }

    private string _content;
    public string Content { get => _content; set => Set(ref _content, value); }

    private bool _isDone;
    public bool IsDone { get => _isDone; set => Set(ref _isDone, value); }

    private string _tags;
    public string Tags { get => _tags; set => Set(ref _tags, value); }

    private string _nextReminder;
    public string NextReminder { get => _nextReminder; set => Set(ref _nextReminder, value); }

    public TaskRowViewModel(string id, string content, bool isDone, string tags, string nextReminder, string? reminderRuleId)
    {
        Id = id;
        ReminderRuleId = reminderRuleId;
        _content = content;
        _isDone = isDone;
        _tags = tags;
        _nextReminder = nextReminder;
    }
}
