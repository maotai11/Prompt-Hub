using StickyRemind.App.Mvvm;

namespace StickyRemind.App;

public sealed class EditTaskDialogViewModel : ObservableObject
{
    private string _content;
    public string Content { get => _content; set => Set(ref _content, value); }

    private string _tags;
    public string Tags { get => _tags; set => Set(ref _tags, value); }

    public EditTaskDialogViewModel(string content, string tags)
    {
        _content = content;
        _tags = tags;
    }
}
