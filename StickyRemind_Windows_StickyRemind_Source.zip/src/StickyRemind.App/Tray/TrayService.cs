using System.Drawing;
using StickyRemind.App;
using System.Windows;
using StickyRemind.Infrastructure.Os;
using Microsoft.Extensions.DependencyInjection;

namespace StickyRemind.App.Tray;

public sealed class TrayService : IDisposable
{
    private readonly StartupService _startup;
    private System.Windows.Forms.NotifyIcon? _icon;
    private StickyWindow? _win;

    public TrayService(StartupService startup)
    {
        _startup = startup;
    }

    public void Initialize(StickyWindow window)
    {
        _win = window;

        _icon = new System.Windows.Forms.NotifyIcon
        {
            Text = "StickyRemind",
            Icon = SystemIcons.Application,
            Visible = true
        };

        _icon.DoubleClick += (_, __) => ShowWindow();

        var menu = new System.Windows.Forms.ContextMenuStrip();

        var show = new System.Windows.Forms.ToolStripMenuItem("Show / Hide");
        show.Click += (_, __) =>
        {
            if (_win == null) return;
            if (_win.IsVisible) _win.Hide();
            else ShowWindow();
        };

        var startup = new System.Windows.Forms.ToolStripMenuItem("Start on boot")
        {
            Checked = _startup.IsEnabled(),
            CheckOnClick = true
        };
        startup.CheckedChanged += (_, __) =>
        {
            try { _startup.SetEnabled(startup.Checked); }
            catch { startup.Checked = _startup.IsEnabled(); }
        };

        var exit = new System.Windows.Forms.ToolStripMenuItem("Exit");
        exit.Click += (_, __) => ExitApp();

        menu.Items.Add(show);
        menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());
        menu.Items.Add(startup);
        menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());
        menu.Items.Add(exit);

        _icon.ContextMenuStrip = menu;
    }

    private void ShowWindow()
    {
        if (_win == null) return;
        Application.Current.Dispatcher.Invoke(() =>
        {
            if (!_win.IsVisible) _win.Show();
            if (_win.WindowState == WindowState.Minimized) _win.WindowState = WindowState.Normal;
            _win.Activate();
        });
    }

    private void ExitApp()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            try
            {
                _win?.RequestExit();
            }
            catch { }

            try
            {
                Application.Current.Shutdown();
            }
            catch { }
        });
    }

    public void Dispose()
    {
        if (_icon != null)
        {
            _icon.Visible = false;
            _icon.Dispose();
            _icon = null;
        }
    }
}
