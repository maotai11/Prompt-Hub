using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace StickyRemind.App;

public partial class StickyWindow : Window
{
    private bool _allowClose;

    public void RequestExit()
    {
        _allowClose = true;
        try { Close(); } catch { }
    }

    public StickyWindow()
    {
        InitializeComponent();
        Loaded += (_, __) => ApplySnap();
        LocationChanged += (_, __) => { /* no-op */ };
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (_allowClose) return;
        // Hide to tray, do not exit.
        e.Cancel = true;
        Hide();
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            WindowState = WindowState == WindowState.Normal ? WindowState.Minimized : WindowState.Normal;
            return;
        }
        DragMove();
        ApplySnap();
    }

    private void Minimize_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void Close_Click(object sender, RoutedEventArgs e)
    {
        Hide();
    }

    private void ApplySnap()
    {
        try
        {
            var screen = System.Windows.Forms.Screen.FromHandle(new System.Windows.Interop.WindowInteropHelper(this).Handle);
            var wa = screen.WorkingArea; // pixel
            var dpi = VisualTreeHelper.GetDpi(this);

            double left = Left * dpi.DpiScaleX;
            double top = Top * dpi.DpiScaleY;
            double width = ActualWidth * dpi.DpiScaleX;
            double height = ActualHeight * dpi.DpiScaleY;

            const int snap = 12;
            if (Math.Abs(left - wa.Left) <= snap) Left = wa.Left / dpi.DpiScaleX;
            if (Math.Abs(top - wa.Top) <= snap) Top = wa.Top / dpi.DpiScaleY;

            if (Math.Abs((left + width) - wa.Right) <= snap) Left = (wa.Right - width) / dpi.DpiScaleX;
            if (Math.Abs((top + height) - wa.Bottom) <= snap) Top = (wa.Bottom - height) / dpi.DpiScaleY;
        }
        catch { }
    }
}
