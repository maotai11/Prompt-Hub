using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using StickyRemind.App.Mvvm;
using StickyRemind.Application.Dtos;
using StickyRemind.Application.Queries;
using StickyRemind.Application.Services;

namespace StickyRemind.App;

public sealed class StickyViewModel : ObservableObject
{
    private readonly ITaskService _tasks;
    private readonly IReminderService _rem;

    public ObservableCollection<TaskRowViewModel> Items { get; } = new();

    private string _newContent = "";
    public string NewContent { get => _newContent; set => Set(ref _newContent, value); }

    private string _newTags = "";
    public string NewTags { get => _newTags; set => Set(ref _newTags, value); }

    private bool _includeDone;
    public bool IncludeDone { get => _includeDone; set { if (Set(ref _includeDone, value)) _ = RefreshAsync(); } }

    private string _searchText = "";
    public string SearchText { get => _searchText; set { if (Set(ref _searchText, value)) _ = RefreshAsync(); } }


    private bool _isTopMost = true;
    public bool IsTopMost { get => _isTopMost; set => Set(ref _isTopMost, value); }

    private double _windowOpacity = 0.95;
    public double WindowOpacity { get => _windowOpacity; set => Set(ref _windowOpacity, Math.Max(0.35, Math.Min(1.0, value))); }
    // Reminder UI
    private bool _enableReminder;
    public bool EnableReminder { get => _enableReminder; set => Set(ref _enableReminder, value); }

    public List<string> ReminderTypes { get; } = new() { "Once", "Daily", "Weekly", "Interval" };

    private string _reminderType = "Once";
    public string ReminderType { get => _reminderType; set => Set(ref _reminderType, value); }

    private DateTime _reminderDate = DateTime.Now.Date;
    public DateTime ReminderDate { get => _reminderDate; set => Set(ref _reminderDate, value); }

    private string _reminderTime = DateTime.Now.AddMinutes(10).ToString("HH:mm");
    public string ReminderTime { get => _reminderTime; set => Set(ref _reminderTime, value); }

    private bool _wMon = true, _wTue, _wWed, _wThu, _wFri, _wSat, _wSun;
    public bool WMon { get => _wMon; set => Set(ref _wMon, value); }
    public bool WTue { get => _wTue; set => Set(ref _wTue, value); }
    public bool WWed { get => _wWed; set => Set(ref _wWed, value); }
    public bool WThu { get => _wThu; set => Set(ref _wThu, value); }
    public bool WFri { get => _wFri; set => Set(ref _wFri, value); }
    public bool WSat { get => _wSat; set => Set(ref _wSat, value); }
    public bool WSun { get => _wSun; set => Set(ref _wSun, value); }

    private string _intervalDays = "2";
    public string IntervalDays { get => _intervalDays; set => Set(ref _intervalDays, value); }

    public ICommand AddCommand { get; }
    public ICommand RefreshCommand { get; }
    public ICommand ToggleDoneCommand { get; }
    public ICommand DeleteCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand Snooze10Command { get; }
    public ICommand Snooze60Command { get; }
    public ICommand ClearReminderCommand { get; }

    private string? _selectedId;
    public string? SelectedId { get => _selectedId; set => Set(ref _selectedId, value); }

    public StickyViewModel(ITaskService tasks, IReminderService rem)
    {
        _tasks = tasks;
        _rem = rem;

        AddCommand = new RelayCommand(async () => await AddAsync());
        RefreshCommand = new RelayCommand(async () => await RefreshAsync());
        ToggleDoneCommand = new RelayCommand<TaskRowViewModel>(async row => await ToggleDoneAsync(row));
        DeleteCommand = new RelayCommand<TaskRowViewModel>(async row => await DeleteAsync(row));
        EditCommand = new RelayCommand<TaskRowViewModel>(async row => await EditAsync(row));
        Snooze10Command = new RelayCommand<TaskRowViewModel>(async row => await SnoozeAsync(row, TimeSpan.FromMinutes(10)));
        Snooze60Command = new RelayCommand<TaskRowViewModel>(async row => await SnoozeAsync(row, TimeSpan.FromMinutes(60)));
        ClearReminderCommand = new RelayCommand<TaskRowViewModel>(async row => await ClearReminderAsync(row));
    }

    public async Task RefreshAsync()
    {
        try
        {
            var q = new TaskQuery { IncludeDone = IncludeDone, SearchText = string.IsNullOrWhiteSpace(SearchText) ? null : SearchText.Trim() };
            var list = await _tasks.SearchAsync(q);

            Application.Current.Dispatcher.Invoke(() =>
            {
                Items.Clear();
                foreach (var t in list)
                {
                    Items.Add(new TaskRowViewModel(
                        t.Id,
                        t.Content,
                        t.IsDone,
                        string.Join(" ", t.Tags.Select(x => "#" + x)),
                        t.NextReminderLocal == null ? "" : t.NextReminderLocal.Value.ToString("yyyy-MM-dd HH:mm"),
                        t.ReminderRuleId
                    ));
                }
            });
        }
        catch { }
    }

    public void SelectTask(string taskId)
    {
        SelectedId = taskId;
    }

    private async Task AddAsync()
    {
        var content = (NewContent ?? "").Trim();
        if (string.IsNullOrWhiteSpace(content)) return;

        var tags = ParseTags(NewTags);

        var req = new CreateTaskRequest { Content = content, Tags = tags };

        var id = await _tasks.CreateAsync(req);

        if (EnableReminder)
        {
            var rr = BuildReminderRequest();
            await _rem.UpsertRuleAsync(id, rr);
        }

        NewContent = "";
        NewTags = "";
        EnableReminder = false;

        await RefreshAsync();
    }

    private ReminderRequest BuildReminderRequest()
    {
        var startLocal = new DateTimeOffset(ReminderDate.Date);
        if (TimeSpan.TryParse(ReminderTime, out var tod))
            startLocal = new DateTimeOffset(ReminderDate.Date.Add(tod));
        else
            startLocal = DateTimeOffset.Now.AddMinutes(10);

        int? weeklyMask = null;
        if (ReminderType.Equals("Weekly", StringComparison.OrdinalIgnoreCase))
        {
            weeklyMask = 0;
            weeklyMask |= WMon ? (1 << 0) : 0;
            weeklyMask |= WTue ? (1 << 1) : 0;
            weeklyMask |= WWed ? (1 << 2) : 0;
            weeklyMask |= WThu ? (1 << 3) : 0;
            weeklyMask |= WFri ? (1 << 4) : 0;
            weeklyMask |= WSat ? (1 << 5) : 0;
            weeklyMask |= WSun ? (1 << 6) : 0;
        }

        int? intervalDays = null;
        if (ReminderType.Equals("Interval", StringComparison.OrdinalIgnoreCase))
        {
            intervalDays = int.TryParse(IntervalDays, out var n) ? Math.Max(1, n) : 2;
        }

        return new ReminderRequest
        {
            Type = ReminderType,
            StartLocal = startLocal,
            TimeOfDayLocal = TimeSpan.TryParse(ReminderTime, out var t) ? t : (TimeSpan?)null,
            WeeklyMask = weeklyMask,
            IntervalDays = intervalDays,
            TimeZoneId = TimeZoneInfo.Local.Id
        };
    }

    private async Task ToggleDoneAsync(TaskRowViewModel? row)
    {
        if (row == null) return;
        await _tasks.SetDoneAsync(row.Id, !row.IsDone);
        await RefreshAsync();
    }

    
    private async Task EditAsync(TaskRowViewModel? row)
    {
        if (row == null) return;

        await Application.Current.Dispatcher.InvokeAsync(() =>
        {
            var vm = new EditTaskDialogViewModel(row.Content, row.Tags);
            var dlg = new EditTaskDialog
            {
                Owner = Application.Current.MainWindow,
                DataContext = vm
            };
            if (dlg.ShowDialog() == true)
            {
                row.Content = vm.Content;
                row.Tags = vm.Tags;
            }
        });

        // persist
        await _tasks.UpdateContentAsync(row.Id, row.Content);
        await _tasks.AssignTagsAsync(row.Id, ParseTags(row.Tags));
        await RefreshAsync();
    }

private async Task DeleteAsync(TaskRowViewModel? row)
    {
        if (row == null) return;
        await _tasks.DeleteAsync(row.Id);
        await RefreshAsync();
    }

    private async Task SnoozeAsync(TaskRowViewModel? row, TimeSpan delay)
    {
        if (row?.ReminderRuleId == null) return;
        await _rem.SnoozeAsync(row.ReminderRuleId, delay, "ui_snooze");
        await RefreshAsync();
    }

    private async Task ClearReminderAsync(TaskRowViewModel? row)
    {
        if (row == null) return;
        await _rem.RemoveRuleAsync(row.Id);
        await RefreshAsync();
    }

    private static List<string> ParseTags(string? s)
    {
        s ??= "";
        return s.Split(new[] { ' ', ',', ';', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.StartsWith("#") ? x[1..] : x)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
    }
}
