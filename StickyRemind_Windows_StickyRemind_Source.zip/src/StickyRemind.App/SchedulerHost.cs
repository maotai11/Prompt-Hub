using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using StickyRemind.Application.Services;

namespace StickyRemind.App;

public sealed class SchedulerHost
{
    private readonly IConfiguration _cfg;
    private readonly IReminderService _rem;
    private readonly ILogger<SchedulerHost> _log;
    private Timer? _timer;

    public SchedulerHost(IConfiguration cfg, IReminderService rem, ILogger<SchedulerHost> log)
    {
        _cfg = cfg;
        _rem = rem;
        _log = log;
    }

    public void Start()
    {
        var tickSec = int.TryParse(_cfg["App:SchedulerTickSeconds"], out var s) ? s : 15;
        _timer = new Timer(async _ =>
        {
            try
            {
                await _rem.RunSchedulerTickAsync();
            }
            catch (Exception ex)
            {
                _log.LogDebug(ex, "Scheduler tick error");
            }
        }, null, TimeSpan.FromSeconds(2), TimeSpan.FromSeconds(Math.Max(5, tickSec)));
    }

    public void Stop()
    {
        _timer?.Dispose();
        _timer = null;
    }
}
