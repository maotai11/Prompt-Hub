using System.Windows;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using StickyRemind.Application.Services;
using StickyRemind.Domain.Engine;
using StickyRemind.Domain.Policy;
using StickyRemind.Infrastructure.Db;
using StickyRemind.Infrastructure.Repositories;
using StickyRemind.Infrastructure.Os;
using StickyRemind.App.Notifications;
using StickyRemind.App.Tray;
using Microsoft.Win32;

namespace StickyRemind.App;

public partial class App : System.Windows.Application
{
    private ServiceProvider? _sp;
    private TrayService? _tray;
    private SchedulerHost? _scheduler;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: true)
            .Build();

        var services = new ServiceCollection();
        services.AddSingleton<IConfiguration>(config);

        services.AddLogging(b =>
        {
            b.AddConsole();
            b.SetMinimumLevel(LogLevel.Information);
        });

        // paths
        var dataFolder = config["App:DataFolderName"] ?? "StickyRemind";
        var dbFile = config["App:DatabaseFileName"] ?? "stickyremind.db";
        var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        var dbPath = Path.Combine(appData, dataFolder, dbFile);

        services.AddSingleton(new AppDbContext(dbPath));
        services.AddSingleton<Migrator>();

        // repos
        services.AddSingleton<TaskRepository>();
        services.AddSingleton<TagRepository>();
        services.AddSingleton<TaskTagRepository>();
        services.AddSingleton<ReminderRepository>();

        // domain engine
        services.AddSingleton<RecurrenceEngine>();

        // toast
        services.AddSingleton<ToastGateway>();

        // application services
        services.AddSingleton<ITaskService, TaskService>();

        var graceSeconds = int.TryParse(config["App:CatchUpGraceSeconds"], out var gs) ? gs : 300;
        var catchUpModeStr = config["App:CatchUpMode"] ?? "coalesce";
        var catchUpMode = catchUpModeStr.Equals("fireall", StringComparison.OrdinalIgnoreCase) ? CatchUpMode.FireAll
                        : catchUpModeStr.Equals("skip", StringComparison.OrdinalIgnoreCase) ? CatchUpMode.Skip
                        : CatchUpMode.Coalesce;

        services.AddSingleton<IReminderService>(sp =>
        {
            return new ReminderService(
                sp.GetRequiredService<ReminderRepository>(),
                sp.GetRequiredService<TaskRepository>(),
                sp.GetRequiredService<RecurrenceEngine>(),
                sp.GetRequiredService<ToastGateway>(),
                TimeSpan.FromSeconds(graceSeconds),
                catchUpMode
            );
        });

        services.AddSingleton<StickyWindow>();
        services.AddSingleton<StickyViewModel>();

        services.AddSingleton(sp =>
        {
            var exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
            return new StartupService("StickyRemind", exePath);
        });

        services.AddSingleton<TrayService>();
        services.AddSingleton<SchedulerHost>();

        _sp = services.BuildServiceProvider();

        // migrate DB
        _sp.GetRequiredService<Migrator>().Migrate();

        // toast activator
        ToastBootstrapper.Initialize(_sp);

        // power/time hooks -> catch-up
        SystemEvents.PowerModeChanged += (_, __) => SafeCatchUp("power");
        SystemEvents.TimeChanged += (_, __) => SafeCatchUp("time");

        // init UI and tray
        var vm = _sp.GetRequiredService<StickyViewModel>();
        var win = _sp.GetRequiredService<StickyWindow>();
        win.DataContext = vm;
        MainWindow = win;

        _tray = _sp.GetRequiredService<TrayService>();
        _tray.Initialize(win);

        _scheduler = _sp.GetRequiredService<SchedulerHost>();
        _scheduler.Start();

        // show window on first run
        win.Show();
        win.Activate();

        _ = vm.RefreshAsync();
    }

    private void SafeCatchUp(string trigger)
    {
        try
        {
            var rem = _sp?.GetRequiredService<IReminderService>();
            if (rem != null) _ = rem.RunCatchUpAsync(trigger);
        }
        catch { }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try
        {
            _scheduler?.Stop();
            _tray?.Dispose();
            _sp?.Dispose();
        }
        catch { }
        base.OnExit(e);
    }
}
