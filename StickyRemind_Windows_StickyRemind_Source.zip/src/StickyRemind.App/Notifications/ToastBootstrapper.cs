using CommunityToolkit.WinUI.Notifications;
using StickyRemind.App;
using Microsoft.Extensions.DependencyInjection;
using StickyRemind.Application.Services;
using System.Runtime.InteropServices;
using System.Windows;

namespace StickyRemind.App.Notifications;

public static class ToastBootstrapper
{
    public static void Initialize(IServiceProvider sp)
    {
        // Handle activation
        ToastNotificationManagerCompat.OnActivated += toastArgs =>
        {
            try
            {
                var args = ToastArguments.Parse(toastArgs.Argument);
                var action = args.TryGetValue("action", out var a) ? a : "open";
                var ruleId = args.TryGetValue("ruleId", out var r) ? r : null;
                var taskId = args.TryGetValue("taskId", out var t) ? t : null;

                var rem = sp.GetRequiredService<IReminderService>();
                var win = sp.GetRequiredService<StickyWindow>();
                var vm = sp.GetRequiredService<StickyViewModel>();

                if (action == "complete" && ruleId != null)
                {
                    _ = rem.CompleteTaskFromRuleAsync(ruleId).ContinueWith(_ => vm.RefreshAsync());
                    return;
                }
                if (action == "snooze10" && ruleId != null)
                {
                    _ = rem.SnoozeAsync(ruleId, TimeSpan.FromMinutes(10), "toast_snooze_10").ContinueWith(_ => vm.RefreshAsync());
                    return;
                }
                if (action == "snooze60" && ruleId != null)
                {
                    _ = rem.SnoozeAsync(ruleId, TimeSpan.FromMinutes(60), "toast_snooze_60").ContinueWith(_ => vm.RefreshAsync());
                    return;
                }

                // open
                Application.Current.Dispatcher.Invoke(() =>
                {
                    if (!win.IsVisible) win.Show();
                    if (win.WindowState == WindowState.Minimized) win.WindowState = WindowState.Normal;
                    win.Activate();
                    if (taskId != null) vm.SelectTask(taskId);
                });
            }
            catch
            {
                // ignore activation errors
            }
        };
    }
}
