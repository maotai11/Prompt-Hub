using CommunityToolkit.WinUI.Notifications;
using StickyRemind.Application.Services;

namespace StickyRemind.App.Notifications;

public sealed class ToastGateway : IToastGateway
{
    public Task ShowTaskToastAsync(string taskId, string ruleId, string occurrenceId, string content)
    {
        var toast = new ToastContentBuilder()
            .AddText("Reminder")
            .AddText(content)
            .AddArgument("action", "open")
            .AddArgument("taskId", taskId)
            .AddArgument("ruleId", ruleId)
            .AddArgument("occId", occurrenceId)
            .AddButton(new ToastButton()
                .SetContent("Complete")
                .AddArgument("action", "complete")
                .AddArgument("ruleId", ruleId)
                )
            .AddButton(new ToastButton()
                .SetContent("Snooze 10m")
                .AddArgument("action", "snooze10")
                .AddArgument("ruleId", ruleId)
                )
            .AddButton(new ToastButton()
                .SetContent("Snooze 60m")
                .AddArgument("action", "snooze60")
                .AddArgument("ruleId", ruleId)
                )
            .Show();

        return Task.CompletedTask;
    }

    public Task ShowCoalescedAsync(int overdueCount)
    {
        new ToastContentBuilder()
            .AddText("Reminders")
            .AddText($"You have {overdueCount} overdue reminders.")
            .AddArgument("action", "open")
            .Show();
        return Task.CompletedTask;
    }
}
