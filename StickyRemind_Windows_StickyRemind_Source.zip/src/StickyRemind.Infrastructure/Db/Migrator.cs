using Microsoft.Data.Sqlite;

namespace StickyRemind.Infrastructure.Db;

public sealed class Migrator
{
    private readonly AppDbContext _db;

    public Migrator(AppDbContext db) => _db = db;

    public void Migrate()
    {
        using var conn = _db.OpenConnection();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS tasks(
  id TEXT PRIMARY KEY,
  content TEXT NOT NULL,
  is_done INTEGER NOT NULL DEFAULT 0,
  created_at_local TEXT NOT NULL,
  created_at_utc_ticks INTEGER NOT NULL,
  done_at_local TEXT NULL,
  updated_at_utc_ticks INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tasks_is_done ON tasks(is_done);
CREATE INDEX IF NOT EXISTS idx_tasks_updated ON tasks(updated_at_utc_ticks);

CREATE TABLE IF NOT EXISTS tags(
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  color TEXT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_archived INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS task_tags(
  task_id TEXT NOT NULL,
  tag_id TEXT NOT NULL,
  PRIMARY KEY(task_id, tag_id),
  FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_task_tags_tag ON task_tags(tag_id);

CREATE TABLE IF NOT EXISTS reminder_rules(
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL UNIQUE,
  type INTEGER NOT NULL,
  start_local TEXT NOT NULL,
  time_of_day_local TEXT NULL,
  interval_days INTEGER NULL,
  weekly_mask INTEGER NULL,
  end_local TEXT NULL,
  timezone_id TEXT NOT NULL,
  created_at_utc_ticks INTEGER NOT NULL,
  FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reminder_state(
  rule_id TEXT PRIMARY KEY,
  next_occurrence_local TEXT NOT NULL,
  next_occurrence_utc_ticks INTEGER NOT NULL,
  series_cursor_local TEXT NOT NULL,
  series_cursor_utc_ticks INTEGER NOT NULL,
  last_fired_local TEXT NULL,
  last_fired_utc_ticks INTEGER NULL,
  status INTEGER NOT NULL DEFAULT 0,
  snooze_until_utc_ticks INTEGER NULL,
  FOREIGN KEY(rule_id) REFERENCES reminder_rules(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_state_next ON reminder_state(next_occurrence_utc_ticks, status);

CREATE TABLE IF NOT EXISTS reminder_adjustments(
  id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL,
  adjusted_at_utc_ticks INTEGER NOT NULL,
  old_next_utc_ticks INTEGER NOT NULL,
  new_next_utc_ticks INTEGER NOT NULL,
  reason TEXT NOT NULL,
  note TEXT NULL,
  FOREIGN KEY(rule_id) REFERENCES reminder_rules(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_adjust_rule_time ON reminder_adjustments(rule_id, adjusted_at_utc_ticks DESC);

CREATE TABLE IF NOT EXISTS occurrence_log(
  id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL,
  planned_utc_ticks INTEGER NOT NULL,
  fired_utc_ticks INTEGER NULL,
  result TEXT NOT NULL,
  meta_json TEXT NULL,
  FOREIGN KEY(rule_id) REFERENCES reminder_rules(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_occ_rule_planned ON occurrence_log(rule_id, planned_utc_ticks DESC);
";
        cmd.ExecuteNonQuery();
    }
}
