using StickyRemind.Domain.Entities;
using StickyRemind.Infrastructure.Db;

namespace StickyRemind.Infrastructure.Repositories;

public sealed class ReminderRepository
{
    private readonly AppDbContext _db;
    public ReminderRepository(AppDbContext db) => _db = db;

    public async Task<(ReminderRule Rule, ReminderState State)?> GetByTaskIdAsync(string taskId)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT r.id,r.task_id,r.type,r.start_local,r.time_of_day_local,r.interval_days,r.weekly_mask,r.end_local,r.timezone_id,r.created_at_utc_ticks,
                                   s.next_occurrence_local,s.next_occurrence_utc_ticks,s.series_cursor_local,s.series_cursor_utc_ticks,
                                   s.last_fired_local,s.last_fired_utc_ticks,s.status,s.snooze_until_utc_ticks
                            FROM reminder_rules r
                            JOIN reminder_state s ON s.rule_id=r.id
                            WHERE r.task_id=$tid
                            LIMIT 1;";
        cmd.Parameters.AddWithValue("$tid", taskId);
        using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;

        var rule = new ReminderRule
        {
            Id = r.GetString(0),
            TaskId = r.GetString(1),
            Type = (ReminderType)r.GetInt32(2),
            StartLocal = DateTimeOffset.Parse(r.GetString(3)),
            TimeOfDayLocal = r.IsDBNull(4) ? null : TimeSpan.Parse(r.GetString(4)),
            IntervalDays = r.IsDBNull(5) ? null : r.GetInt32(5),
            WeeklyMask = r.IsDBNull(6) ? null : r.GetInt32(6),
            EndLocal = r.IsDBNull(7) ? null : DateTimeOffset.Parse(r.GetString(7)),
            TimeZoneId = r.GetString(8),
            CreatedAtUtcTicks = r.GetInt64(9)
        };

        var state = new ReminderState
        {
            RuleId = rule.Id,
            NextOccurrenceLocal = DateTimeOffset.Parse(r.GetString(10)),
            NextOccurrenceUtcTicks = r.GetInt64(11),
            SeriesCursorLocal = DateTimeOffset.Parse(r.GetString(12)),
            SeriesCursorUtcTicks = r.GetInt64(13),
            LastFiredLocal = r.IsDBNull(14) ? null : DateTimeOffset.Parse(r.GetString(14)),
            LastFiredUtcTicks = r.IsDBNull(15) ? null : r.GetInt64(15),
            Status = (ReminderStatus)r.GetInt32(16),
            SnoozeUntilUtcTicks = r.IsDBNull(17) ? null : r.GetInt64(17)
        };

        return (rule, state);
    }

    public async Task<(ReminderRule Rule, ReminderState State)?> GetByRuleIdAsync(string ruleId)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT r.id,r.task_id,r.type,r.start_local,r.time_of_day_local,r.interval_days,r.weekly_mask,r.end_local,r.timezone_id,r.created_at_utc_ticks,
                                   s.next_occurrence_local,s.next_occurrence_utc_ticks,s.series_cursor_local,s.series_cursor_utc_ticks,
                                   s.last_fired_local,s.last_fired_utc_ticks,s.status,s.snooze_until_utc_ticks
                            FROM reminder_rules r
                            JOIN reminder_state s ON s.rule_id=r.id
                            WHERE r.id=$rid
                            LIMIT 1;";
        cmd.Parameters.AddWithValue("$rid", ruleId);
        using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;

        var rule = new ReminderRule
        {
            Id = r.GetString(0),
            TaskId = r.GetString(1),
            Type = (ReminderType)r.GetInt32(2),
            StartLocal = DateTimeOffset.Parse(r.GetString(3)),
            TimeOfDayLocal = r.IsDBNull(4) ? null : TimeSpan.Parse(r.GetString(4)),
            IntervalDays = r.IsDBNull(5) ? null : r.GetInt32(5),
            WeeklyMask = r.IsDBNull(6) ? null : r.GetInt32(6),
            EndLocal = r.IsDBNull(7) ? null : DateTimeOffset.Parse(r.GetString(7)),
            TimeZoneId = r.GetString(8),
            CreatedAtUtcTicks = r.GetInt64(9)
        };

        var state = new ReminderState
        {
            RuleId = rule.Id,
            NextOccurrenceLocal = DateTimeOffset.Parse(r.GetString(10)),
            NextOccurrenceUtcTicks = r.GetInt64(11),
            SeriesCursorLocal = DateTimeOffset.Parse(r.GetString(12)),
            SeriesCursorUtcTicks = r.GetInt64(13),
            LastFiredLocal = r.IsDBNull(14) ? null : DateTimeOffset.Parse(r.GetString(14)),
            LastFiredUtcTicks = r.IsDBNull(15) ? null : r.GetInt64(15),
            Status = (ReminderStatus)r.GetInt32(16),
            SnoozeUntilUtcTicks = r.IsDBNull(17) ? null : r.GetInt64(17)
        };

        return (rule, state);
    }

    public async Task UpsertRuleAndStateAsync(ReminderRule rule, ReminderState state)
    {
        using var conn = _db.OpenConnection();
        using var tx = conn.BeginTransaction();

        using (var up = conn.CreateCommand())
        {
            up.Transaction = tx;
            up.CommandText = @"
INSERT INTO reminder_rules(id,task_id,type,start_local,time_of_day_local,interval_days,weekly_mask,end_local,timezone_id,created_at_utc_ticks)
VALUES($id,$tid,$type,$start,$tod,$int,$mask,$end,$tz,$cat)
ON CONFLICT(task_id) DO UPDATE SET
  id=excluded.id,
  type=excluded.type,
  start_local=excluded.start_local,
  time_of_day_local=excluded.time_of_day_local,
  interval_days=excluded.interval_days,
  weekly_mask=excluded.weekly_mask,
  end_local=excluded.end_local,
  timezone_id=excluded.timezone_id
;";
            up.Parameters.AddWithValue("$id", rule.Id);
            up.Parameters.AddWithValue("$tid", rule.TaskId);
            up.Parameters.AddWithValue("$type", (int)rule.Type);
            up.Parameters.AddWithValue("$start", rule.StartLocal.ToString("o"));
            up.Parameters.AddWithValue("$tod", (object?)rule.TimeOfDayLocal?.ToString() ?? DBNull.Value);
            up.Parameters.AddWithValue("$int", (object?)rule.IntervalDays ?? DBNull.Value);
            up.Parameters.AddWithValue("$mask", (object?)rule.WeeklyMask ?? DBNull.Value);
            up.Parameters.AddWithValue("$end", (object?)rule.EndLocal?.ToString("o") ?? DBNull.Value);
            up.Parameters.AddWithValue("$tz", rule.TimeZoneId);
            up.Parameters.AddWithValue("$cat", rule.CreatedAtUtcTicks);
            await up.ExecuteNonQueryAsync();
        }

        using (var ups = conn.CreateCommand())
        {
            ups.Transaction = tx;
            ups.CommandText = @"
INSERT INTO reminder_state(rule_id,next_occurrence_local,next_occurrence_utc_ticks,series_cursor_local,series_cursor_utc_ticks,last_fired_local,last_fired_utc_ticks,status,snooze_until_utc_ticks)
VALUES($rid,$nol,$nou,$scl,$scu,$lfl,$lfu,$st,$snooze)
ON CONFLICT(rule_id) DO UPDATE SET
  next_occurrence_local=excluded.next_occurrence_local,
  next_occurrence_utc_ticks=excluded.next_occurrence_utc_ticks,
  series_cursor_local=excluded.series_cursor_local,
  series_cursor_utc_ticks=excluded.series_cursor_utc_ticks,
  last_fired_local=excluded.last_fired_local,
  last_fired_utc_ticks=excluded.last_fired_utc_ticks,
  status=excluded.status,
  snooze_until_utc_ticks=excluded.snooze_until_utc_ticks
;";
            ups.Parameters.AddWithValue("$rid", state.RuleId);
            ups.Parameters.AddWithValue("$nol", state.NextOccurrenceLocal.ToString("o"));
            ups.Parameters.AddWithValue("$nou", state.NextOccurrenceUtcTicks);
            ups.Parameters.AddWithValue("$scl", state.SeriesCursorLocal.ToString("o"));
            ups.Parameters.AddWithValue("$scu", state.SeriesCursorUtcTicks);
            ups.Parameters.AddWithValue("$lfl", (object?)state.LastFiredLocal?.ToString("o") ?? DBNull.Value);
            ups.Parameters.AddWithValue("$lfu", (object?)state.LastFiredUtcTicks ?? DBNull.Value);
            ups.Parameters.AddWithValue("$st", (int)state.Status);
            ups.Parameters.AddWithValue("$snooze", (object?)state.SnoozeUntilUtcTicks ?? DBNull.Value);
            await ups.ExecuteNonQueryAsync();
        }

        await tx.CommitAsync();
    }

    public async Task<List<(ReminderRule Rule, ReminderState State)>> ListDueAsync(long nowUtcTicks, int limit=50)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT r.id,r.task_id,r.type,r.start_local,r.time_of_day_local,r.interval_days,r.weekly_mask,r.end_local,r.timezone_id,r.created_at_utc_ticks,
       s.next_occurrence_local,s.next_occurrence_utc_ticks,s.series_cursor_local,s.series_cursor_utc_ticks,
       s.last_fired_local,s.last_fired_utc_ticks,s.status,s.snooze_until_utc_ticks
FROM reminder_rules r
JOIN reminder_state s ON s.rule_id=r.id
WHERE s.status=0
  AND s.next_occurrence_utc_ticks <= $now
  AND (s.snooze_until_utc_ticks IS NULL OR s.snooze_until_utc_ticks <= $now)
ORDER BY s.next_occurrence_utc_ticks ASC
LIMIT $lim;";
        cmd.Parameters.AddWithValue("$now", nowUtcTicks);
        cmd.Parameters.AddWithValue("$lim", limit);

        using var r = await cmd.ExecuteReaderAsync();
        var list = new List<(ReminderRule, ReminderState)>();
        while (await r.ReadAsync())
        {
            var rule = new ReminderRule
            {
                Id = r.GetString(0),
                TaskId = r.GetString(1),
                Type = (ReminderType)r.GetInt32(2),
                StartLocal = DateTimeOffset.Parse(r.GetString(3)),
                TimeOfDayLocal = r.IsDBNull(4) ? null : TimeSpan.Parse(r.GetString(4)),
                IntervalDays = r.IsDBNull(5) ? null : r.GetInt32(5),
                WeeklyMask = r.IsDBNull(6) ? null : r.GetInt32(6),
                EndLocal = r.IsDBNull(7) ? null : DateTimeOffset.Parse(r.GetString(7)),
                TimeZoneId = r.GetString(8),
                CreatedAtUtcTicks = r.GetInt64(9)
            };
            var state = new ReminderState
            {
                RuleId = rule.Id,
                NextOccurrenceLocal = DateTimeOffset.Parse(r.GetString(10)),
                NextOccurrenceUtcTicks = r.GetInt64(11),
                SeriesCursorLocal = DateTimeOffset.Parse(r.GetString(12)),
                SeriesCursorUtcTicks = r.GetInt64(13),
                LastFiredLocal = r.IsDBNull(14) ? null : DateTimeOffset.Parse(r.GetString(14)),
                LastFiredUtcTicks = r.IsDBNull(15) ? null : r.GetInt64(15),
                Status = (ReminderStatus)r.GetInt32(16),
                SnoozeUntilUtcTicks = r.IsDBNull(17) ? null : r.GetInt64(17)
            };
            list.Add((rule, state));
        }
        return list;
    }

    public async Task AddAdjustmentAsync(ReminderAdjustment adj)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"INSERT INTO reminder_adjustments(id,rule_id,adjusted_at_utc_ticks,old_next_utc_ticks,new_next_utc_ticks,reason,note)
                            VALUES($id,$rid,$at,$old,$new,$reason,$note);";
        cmd.Parameters.AddWithValue("$id", adj.Id);
        cmd.Parameters.AddWithValue("$rid", adj.RuleId);
        cmd.Parameters.AddWithValue("$at", adj.AdjustedAtUtcTicks);
        cmd.Parameters.AddWithValue("$old", adj.OldNextUtcTicks);
        cmd.Parameters.AddWithValue("$new", adj.NewNextUtcTicks);
        cmd.Parameters.AddWithValue("$reason", adj.Reason);
        cmd.Parameters.AddWithValue("$note", (object?)adj.Note ?? DBNull.Value);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task AddOccurrenceLogAsync(OccurrenceLog log)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"INSERT INTO occurrence_log(id,rule_id,planned_utc_ticks,fired_utc_ticks,result,meta_json)
                            VALUES($id,$rid,$p,$f,$res,$m);";
        cmd.Parameters.AddWithValue("$id", log.Id);
        cmd.Parameters.AddWithValue("$rid", log.RuleId);
        cmd.Parameters.AddWithValue("$p", log.PlannedUtcTicks);
        cmd.Parameters.AddWithValue("$f", (object?)log.FiredUtcTicks ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$res", log.Result);
        cmd.Parameters.AddWithValue("$m", (object?)log.MetaJson ?? DBNull.Value);
        await cmd.ExecuteNonQueryAsync();
    }
}
