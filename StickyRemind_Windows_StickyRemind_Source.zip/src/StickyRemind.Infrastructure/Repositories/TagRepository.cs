using Microsoft.Data.Sqlite;
using StickyRemind.Domain.Entities;
using StickyRemind.Infrastructure.Db;

namespace StickyRemind.Infrastructure.Repositories;

public sealed class TagRepository
{
    private readonly AppDbContext _db;
    public TagRepository(AppDbContext db) => _db = db;

    public async Task<Tag> UpsertByNameAsync(string name)
    {
        name = name.Trim();
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Tag name empty.");

        using var conn = _db.OpenConnection();

        // check exist
        using (var check = conn.CreateCommand())
        {
            check.CommandText = "SELECT id, name, color, sort_order, is_archived FROM tags WHERE name=$name LIMIT 1;";
            check.Parameters.AddWithValue("$name", name);
            using var r = await check.ExecuteReaderAsync();
            if (await r.ReadAsync())
            {
                return new Tag
                {
                    Id = r.GetString(0),
                    Name = r.GetString(1),
                    Color = r.IsDBNull(2) ? null : r.GetString(2),
                    SortOrder = r.GetInt32(3),
                    IsArchived = r.GetInt32(4) == 1
                };
            }
        }

        var tag = new Tag { Name = name };
        using (var ins = conn.CreateCommand())
        {
            ins.CommandText = "INSERT INTO tags(id,name,color,sort_order,is_archived) VALUES($id,$name,$color,$sort,$arch);";
            ins.Parameters.AddWithValue("$id", tag.Id);
            ins.Parameters.AddWithValue("$name", tag.Name);
            ins.Parameters.AddWithValue("$color", (object?)tag.Color ?? DBNull.Value);
            ins.Parameters.AddWithValue("$sort", tag.SortOrder);
            ins.Parameters.AddWithValue("$arch", tag.IsArchived ? 1 : 0);
            await ins.ExecuteNonQueryAsync();
        }
        return tag;
    }

    public async Task<List<Tag>> ListAsync(bool includeArchived=false)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = includeArchived
            ? "SELECT id,name,color,sort_order,is_archived FROM tags ORDER BY sort_order, name;"
            : "SELECT id,name,color,sort_order,is_archived FROM tags WHERE is_archived=0 ORDER BY sort_order, name;";
        using var r = await cmd.ExecuteReaderAsync();
        var list = new List<Tag>();
        while (await r.ReadAsync())
        {
            list.Add(new Tag
            {
                Id = r.GetString(0),
                Name = r.GetString(1),
                Color = r.IsDBNull(2) ? null : r.GetString(2),
                SortOrder = r.GetInt32(3),
                IsArchived = r.GetInt32(4) == 1
            });
        }
        return list;
    }
}
