using Microsoft.Data.Sqlite;
using StickyRemind.Domain.Entities;
using StickyRemind.Infrastructure.Db;

namespace StickyRemind.Infrastructure.Repositories;

public sealed class TaskRepository
{
    private readonly AppDbContext _db;
    public TaskRepository(AppDbContext db) => _db = db;

    public async Task InsertAsync(TaskItem t)
    {
        using var conn = _db.OpenConnection();
        using var tx = conn.BeginTransaction();

        using (var cmd = conn.CreateCommand())
        {
            cmd.Transaction = tx;
            cmd.CommandText = @"INSERT INTO tasks(id,content,is_done,created_at_local,created_at_utc_ticks,done_at_local,updated_at_utc_ticks)
                                VALUES($id,$c,$d,$cal,$cat,$dal,$u);";
            cmd.Parameters.AddWithValue("$id", t.Id);
            cmd.Parameters.AddWithValue("$c", t.Content);
            cmd.Parameters.AddWithValue("$d", t.IsDone ? 1 : 0);
            cmd.Parameters.AddWithValue("$cal", t.CreatedAtLocal.ToString("o"));
            cmd.Parameters.AddWithValue("$cat", t.CreatedAtUtcTicks);
            cmd.Parameters.AddWithValue("$dal", (object?)t.DoneAtLocal?.ToString("o") ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$u", t.UpdatedAtUtcTicks);
            await cmd.ExecuteNonQueryAsync();
        }

        await tx.CommitAsync();
    }

    public async Task UpdateContentAsync(string id, string content)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE tasks SET content=$c, updated_at_utc_ticks=$u WHERE id=$id;";
        cmd.Parameters.AddWithValue("$c", content);
        cmd.Parameters.AddWithValue("$u", DateTimeOffset.UtcNow.UtcTicks);
        cmd.Parameters.AddWithValue("$id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task SetDoneAsync(string id, bool isDone)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE tasks SET is_done=$d, done_at_local=$dal, updated_at_utc_ticks=$u WHERE id=$id;";
        cmd.Parameters.AddWithValue("$d", isDone ? 1 : 0);
        cmd.Parameters.AddWithValue("$dal", isDone ? DateTimeOffset.Now.ToString("o") : (object)DBNull.Value);
        cmd.Parameters.AddWithValue("$u", DateTimeOffset.UtcNow.UtcTicks);
        cmd.Parameters.AddWithValue("$id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteAsync(string id)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM tasks WHERE id=$id;";
        cmd.Parameters.AddWithValue("$id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<TaskItem?> GetAsync(string id)
    {
        using var conn = _db.OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT id,content,is_done,created_at_local,created_at_utc_ticks,done_at_local,updated_at_utc_ticks FROM tasks WHERE id=$id LIMIT 1;";
        cmd.Parameters.AddWithValue("$id", id);
        using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;
        return new TaskItem
        {
            Id = r.GetString(0),
            Content = r.GetString(1),
            IsDone = r.GetInt32(2) == 1,
            CreatedAtLocal = DateTimeOffset.Parse(r.GetString(3)),
            CreatedAtUtcTicks = r.GetInt64(4),
            DoneAtLocal = r.IsDBNull(5) ? null : DateTimeOffset.Parse(r.GetString(5)),
            UpdatedAtUtcTicks = r.GetInt64(6)
        };
    }

    public async Task<List<(TaskItem Task, List<string> Tags)>> SearchAsync(bool includeDone, string? searchText, List<string>? tagsAny)
    {
        using var conn = _db.OpenConnection();

        // simple search: tasks + tag filtering via EXISTS
        var where = new List<string>();
        if (!includeDone) where.Add("t.is_done=0");
        if (!string.IsNullOrWhiteSpace(searchText)) where.Add("t.content LIKE $q");

        string tagFilter = "";
        if (tagsAny is { Count: > 0 })
        {
            tagFilter = @" AND EXISTS(
                SELECT 1 FROM task_tags tt
                JOIN tags g ON g.id=tt.tag_id
                WHERE tt.task_id=t.id AND g.name IN (" + string.Join(",", tagsAny.Select((_,i)=>"$tag"+i)) + @")
            )";
        }

        var sql = @"SELECT t.id,t.content,t.is_done,t.created_at_local,t.created_at_utc_ticks,t.done_at_local,t.updated_at_utc_ticks
                    FROM tasks t
                    WHERE " + (where.Count == 0 ? "1=1" : string.Join(" AND ", where)) + tagFilter + @"
                    ORDER BY t.is_done ASC, t.updated_at_utc_ticks DESC
                    LIMIT 500;";

        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        if (!string.IsNullOrWhiteSpace(searchText)) cmd.Parameters.AddWithValue("$q", "%" + searchText.Trim() + "%");
        if (tagsAny is { Count: > 0 })
        {
            for (int i = 0; i < tagsAny.Count; i++)
                cmd.Parameters.AddWithValue("$tag" + i, tagsAny[i]);
        }

        var list = new List<(TaskItem, List<string>)>();
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            var task = new TaskItem
            {
                Id = r.GetString(0),
                Content = r.GetString(1),
                IsDone = r.GetInt32(2) == 1,
                CreatedAtLocal = DateTimeOffset.Parse(r.GetString(3)),
                CreatedAtUtcTicks = r.GetInt64(4),
                DoneAtLocal = r.IsDBNull(5) ? null : DateTimeOffset.Parse(r.GetString(5)),
                UpdatedAtUtcTicks = r.GetInt64(6)
            };
            var tags = await GetTagsForTaskAsync(conn, task.Id);
            list.Add((task, tags));
        }
        return list;
    }

    private static async Task<List<string>> GetTagsForTaskAsync(SqliteConnection conn, string taskId)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT g.name FROM task_tags tt
                            JOIN tags g ON g.id=tt.tag_id
                            WHERE tt.task_id=$tid
                            ORDER BY g.sort_order, g.name;";
        cmd.Parameters.AddWithValue("$tid", taskId);
        using var r = await cmd.ExecuteReaderAsync();
        var tags = new List<string>();
        while (await r.ReadAsync())
            tags.Add(r.GetString(0));
        return tags;
    }
}
