using StickyRemind.Infrastructure.Db;

namespace StickyRemind.Infrastructure.Repositories;

public sealed class TaskTagRepository
{
    private readonly AppDbContext _db;
    public TaskTagRepository(AppDbContext db) => _db = db;

    public async Task ReplaceTagsAsync(string taskId, List<string> tagIds)
    {
        using var conn = _db.OpenConnection();
        using var tx = conn.BeginTransaction();

        using (var del = conn.CreateCommand())
        {
            del.Transaction = tx;
            del.CommandText = "DELETE FROM task_tags WHERE task_id=$tid;";
            del.Parameters.AddWithValue("$tid", taskId);
            await del.ExecuteNonQueryAsync();
        }

        foreach (var tagId in tagIds.Distinct())
        {
            using var ins = conn.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = "INSERT OR IGNORE INTO task_tags(task_id,tag_id) VALUES($tid,$gid);";
            ins.Parameters.AddWithValue("$tid", taskId);
            ins.Parameters.AddWithValue("$gid", tagId);
            await ins.ExecuteNonQueryAsync();
        }

        await tx.CommitAsync();
    }
}
