using System.Text;

namespace StickyRemind.Infrastructure.Interop;

public sealed class CsvExport
{
    public string Export(IEnumerable<(string Content, string Tags, int IsDone, string CreatedAtLocal, string? NextReminderLocal, string RecurrenceType, string? RecurrenceParam)> rows)
    {
        var sb = new StringBuilder();
        sb.AppendLine("content,tags,isDone,createdAtLocal,nextReminderLocal,recurrenceType,recurrenceParam");
        foreach (var r in rows)
        {
            sb.AppendLine(string.Join(",",
                Esc(r.Content),
                Esc(r.Tags),
                r.IsDone.ToString(),
                Esc(r.CreatedAtLocal),
                Esc(r.NextReminderLocal ?? ""),
                Esc(r.RecurrenceType),
                Esc(r.RecurrenceParam ?? "")
            ));
        }
        return sb.ToString();
    }

    private static string Esc(string s)
    {
        s ??= "";
        if (s.Contains('"') || s.Contains(',') || s.Contains('\n') || s.Contains('\r'))
        {
            return """ + s.Replace(""", """") + """;
        }
        return s;
    }
}
