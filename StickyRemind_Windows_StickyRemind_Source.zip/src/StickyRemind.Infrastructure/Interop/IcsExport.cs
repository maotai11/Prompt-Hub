using System.Text;

namespace StickyRemind.Infrastructure.Interop;

public sealed class IcsExport
{
    public string Export(IEnumerable<IcsEvent> events)
    {
        var sb = new StringBuilder();
        sb.AppendLine("BEGIN:VCALENDAR");
        sb.AppendLine("VERSION:2.0");
        sb.AppendLine("PRODID:-//StickyRemind//EN");

        foreach (var e in events)
        {
            sb.AppendLine("BEGIN:VEVENT");
            sb.AppendLine("UID:" + e.Uid);
            sb.AppendLine("DTSTAMP:" + ToIcsUtc(DateTimeOffset.UtcNow));
            sb.AppendLine("SUMMARY:" + EscapeText(e.Summary));
            sb.AppendLine("DESCRIPTION:" + EscapeText(e.Description ?? ""));
            sb.AppendLine("DTSTART:" + ToIcsUtc(e.StartUtc));
            if (!string.IsNullOrWhiteSpace(e.RRule))
                sb.AppendLine("RRULE:" + e.RRule);
            sb.AppendLine("END:VEVENT");
        }

        sb.AppendLine("END:VCALENDAR");
        return sb.ToString();
    }

    private static string ToIcsUtc(DateTimeOffset utc) => utc.ToUniversalTime().ToString("yyyyMMdd'T'HHmmss'Z'");
    private static string EscapeText(string s) => s.Replace("\\", "\\\\").Replace(";", "\\;").Replace(",", "\\,").Replace("\n", "\\n");
}

public sealed class IcsEvent
{
    public string Uid { get; set; } = Guid.NewGuid().ToString("N");
    public string Summary { get; set; } = "";
    public string? Description { get; set; }
    public DateTimeOffset StartUtc { get; set; }
    public string? RRule { get; set; }
}
