using System.Text.Json;
using StickyRemind.Domain.Entities;

namespace StickyRemind.Infrastructure.Interop;

public sealed class JsonExportImport
{
    private static readonly JsonSerializerOptions Opt = new()
    {
        WriteIndented = true
    };

    public string Export(ExportBundle bundle) => JsonSerializer.Serialize(bundle, Opt);

    public ExportBundle Import(string json)
    {
        var b = JsonSerializer.Deserialize<ExportBundle>(json, Opt);
        if (b == null) throw new InvalidOperationException("Invalid JSON bundle.");
        return b;
    }
}

public sealed class ExportBundle
{
    public int SchemaVersion { get; set; } = 1;
    public DateTimeOffset ExportedAtUtc { get; set; } = DateTimeOffset.UtcNow;

    public List<TaskRecord> Tasks { get; set; } = new();
}

public sealed class TaskRecord
{
    public TaskItem Task { get; set; } = new();
    public List<string> Tags { get; set; } = new();

    public ReminderRule? Rule { get; set; }
    public ReminderState? State { get; set; }
}
