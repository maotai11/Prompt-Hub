using Microsoft.Win32;

namespace StickyRemind.Infrastructure.Os;

public sealed class StartupService
{
    private const string RunKeyPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    private readonly string _appName;
    private readonly string _exePath;

    public StartupService(string appName, string exePath)
    {
        _appName = appName;
        _exePath = exePath;
    }

    public bool IsEnabled()
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, false);
        var v = key?.GetValue(_appName) as string;
        return !string.IsNullOrWhiteSpace(v);
    }

    public void SetEnabled(bool enabled)
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, true) ?? Registry.CurrentUser.CreateSubKey(RunKeyPath, true);
        if (enabled)
        {
            key.SetValue(_appName, """ + _exePath + """);
        }
        else
        {
            key.DeleteValue(_appName, false);
        }
    }
}
