using StickyRemind.Application.Dtos;
using StickyRemind.Domain.Entities;
using StickyRemind.Domain.Engine;
using StickyRemind.Domain.Policy;
using StickyRemind.Infrastructure.Repositories;

namespace StickyRemind.Application.Services;

public sealed class ReminderService : IReminderService
{
    private readonly ReminderRepository _repo;
    private readonly TaskRepository _tasks;
    private readonly RecurrenceEngine _engine;
    private readonly IToastGateway _toast;
    private readonly long _graceTicks;
    private readonly CatchUpMode _catchUpMode;

    public ReminderService(
        ReminderRepository repo,
        TaskRepository tasks,
        RecurrenceEngine engine,
        IToastGateway toast,
        TimeSpan graceWindow,
        CatchUpMode catchUpMode)
    {
        _repo = repo;
        _tasks = tasks;
        _engine = engine;
        _toast = toast;
        _graceTicks = graceWindow.Ticks;
        _catchUpMode = catchUpMode;
    }

    public async Task UpsertRuleAsync(string taskId, ReminderRequest req)
    {
        var t = await _tasks.GetAsync(taskId) ?? throw new InvalidOperationException("Task not found.");

        var type = Enum.TryParse<ReminderType>(req.Type, ignoreCase: true, out var rt) ? rt : ReminderType.None;
        if (type == ReminderType.None)
        {
            await RemoveRuleAsync(taskId);
            return;
        }

        var rule = new ReminderRule
        {
            TaskId = taskId,
            Type = type,
            StartLocal = req.StartLocal,
            TimeOfDayLocal = req.TimeOfDayLocal,
            WeeklyMask = req.WeeklyMask,
            IntervalDays = req.IntervalDays,
            TimeZoneId = req.TimeZoneId ?? TimeZoneInfo.Local.Id,
            CreatedAtUtcTicks = DateTimeOffset.UtcNow.UtcTicks
        };

        // Initial next occurrence is rule-aligned. We keep SeriesCursorLocal as the next rule-aligned occurrence (anchor).
        var first = _engine.ComputeFirstNext(rule);
        var state = new ReminderState
        {
            RuleId = rule.Id,
            NextOccurrenceLocal = first,
            NextOccurrenceUtcTicks = first.ToUniversalTime().UtcTicks,
            SeriesCursorLocal = first,
            SeriesCursorUtcTicks = first.ToUniversalTime().UtcTicks,
            Status = ReminderStatus.Active
        };

        await _repo.UpsertRuleAndStateAsync(rule, state);
    }

    public async Task RemoveRuleAsync(string taskId)
    {
        // For MVP: set status=Completed by loading and updating.
        var rs = await _repo.GetByTaskIdAsync(taskId);
        if (rs == null) return;
        rs.Value.State.Status = ReminderStatus.Completed;
        await _repo.UpsertRuleAndStateAsync(rs.Value.Rule, rs.Value.State);
    }

    public async Task SnoozeAsync(string ruleId, TimeSpan delay, string reason)
    {
        var rs = await _repo.GetByRuleIdAsync(ruleId) ?? throw new InvalidOperationException("Rule not found.");
        var state = rs.Value.State;

        var old = state.NextOccurrenceUtcTicks;
        var nowUtc = DateTimeOffset.UtcNow.UtcTicks;
        var newNextUtc = Math.Max(nowUtc + delay.Ticks, nowUtc + TimeSpan.FromSeconds(5).Ticks);

        state.NextOccurrenceUtcTicks = newNextUtc;
        state.NextOccurrenceLocal = new DateTimeOffset(new DateTime(newNextUtc, DateTimeKind.Utc)).ToLocalTime();

        await _repo.AddAdjustmentAsync(new ReminderAdjustment
        {
            RuleId = ruleId,
            OldNextUtcTicks = old,
            NewNextUtcTicks = newNextUtc,
            Reason = reason
        });

        await _repo.UpsertRuleAndStateAsync(rs.Value.Rule, state);
    }

    public async Task CompleteTaskFromRuleAsync(string ruleId)
    {
        var rs = await _repo.GetByRuleIdAsync(ruleId);
        if (rs == null) return;
        await _tasks.SetDoneAsync(rs.Value.Rule.TaskId, true);

        rs.Value.State.Status = ReminderStatus.Completed;
        await _repo.UpsertRuleAndStateAsync(rs.Value.Rule, rs.Value.State);
    }

    public async Task OpenTaskFromRuleAsync(string ruleId)
    {
        await Task.CompletedTask;
    }

    public async Task RunSchedulerTickAsync()
    {
        var nowUtc = DateTimeOffset.UtcNow.UtcTicks;
        var due = await _repo.ListDueAsync(nowUtc, 50);
        foreach (var (rule, state) in due)
        {
            await FireOccurrenceAsync(rule, state, nowUtc, trigger: "tick");
        }
    }

    public async Task RunCatchUpAsync(string trigger)
    {
        var nowUtc = DateTimeOffset.UtcNow;
        var nowLocal = DateTimeOffset.Now;

        var due = await _repo.ListDueAsync(nowUtc.UtcTicks, 200);
        if (due.Count == 0) return;

        if (_catchUpMode == CatchUpMode.Skip)
        {
            foreach (var (rule, state) in due)
                await CatchUpAdvanceAsync(rule, state, nowLocal, coalesced: false, trigger);
            return;
        }

        if (_catchUpMode == CatchUpMode.FireAll)
        {
            foreach (var (rule, state) in due)
                await FireOccurrenceAsync(rule, state, nowUtc.UtcTicks, trigger: "catchup");
            return;
        }

        // Coalesce
        await _toast.ShowCoalescedAsync(due.Select(x => x.Rule.TaskId).Distinct().Count());
        foreach (var (rule, state) in due)
            await CatchUpAdvanceAsync(rule, state, nowLocal, coalesced: true, trigger);
    }

    private async Task FireOccurrenceAsync(ReminderRule rule, ReminderState state, long nowUtcTicks, string trigger)
    {
        var task = await _tasks.GetAsync(rule.TaskId);
        if (task == null) return;
        if (task.IsDone)
        {
            state.Status = ReminderStatus.Completed;
            await _repo.UpsertRuleAndStateAsync(rule, state);
            return;
        }

        // Overdue beyond grace -> let global catch-up handle in coalesce mode
        if (nowUtcTicks - state.NextOccurrenceUtcTicks > _graceTicks && _catchUpMode == CatchUpMode.Coalesce && trigger == "tick")
            return;

        var occurrenceId = Guid.NewGuid().ToString("N");

        await _repo.AddOccurrenceLogAsync(new OccurrenceLog
        {
            RuleId = rule.Id,
            PlannedUtcTicks = state.NextOccurrenceUtcTicks,
            FiredUtcTicks = nowUtcTicks,
            Result = "fired",
            MetaJson = "{"trigger":"" + trigger + ""}"
        });

        await _toast.ShowTaskToastAsync(task.Id, rule.Id, occurrenceId, task.Content);

        await AdvanceAfterFireAsync(rule, state, nowUtcTicks);
    }

    private async Task AdvanceAfterFireAsync(ReminderRule rule, ReminderState state, long firedUtcTicks)
    {
        state.LastFiredUtcTicks = firedUtcTicks;
        state.LastFiredLocal = DateTimeOffset.UtcNow.ToLocalTime();

        if (rule.Type == ReminderType.Once)
        {
            state.Status = ReminderStatus.Completed;
            await _repo.UpsertRuleAndStateAsync(rule, state);
            return;
        }

        // IMPORTANT:
        // SeriesCursorLocal anchors the recurrence series at the next rule-aligned occurrence.
        // If user snoozed, NextOccurrenceLocal may be off-series, but SeriesCursorLocal stays on-series.
        // After any fire (even snoozed), we advance SeriesCursorLocal by exactly one step and set NextOccurrence to that.
        var nextAligned = _engine.ComputeNextFromCursor(state.SeriesCursorLocal, rule);

        state.SeriesCursorLocal = nextAligned;
        state.SeriesCursorUtcTicks = nextAligned.ToUniversalTime().UtcTicks;

        state.NextOccurrenceLocal = nextAligned;
        state.NextOccurrenceUtcTicks = nextAligned.ToUniversalTime().UtcTicks;

        await _repo.UpsertRuleAndStateAsync(rule, state);
    }

    private async Task CatchUpAdvanceAsync(ReminderRule rule, ReminderState state, DateTimeOffset nowLocal, bool coalesced, string trigger)
    {
        // compute missed occurrences based on current NEXT (which might be off-series, but in coalesce mode we want to move series cursor forward)
        // we use series cursor as the on-series anchor.
        var missed = _engine.ComputeMissedOccurrences(state.SeriesCursorLocal, nowLocal, rule, max: 64).ToList();
        if (missed.Count == 0) return;

        foreach (var m in missed)
        {
            await _repo.AddOccurrenceLogAsync(new OccurrenceLog
            {
                RuleId = rule.Id,
                PlannedUtcTicks = m.ToUniversalTime().UtcTicks,
                FiredUtcTicks = null,
                Result = coalesced ? "coalesced" : "skipped",
                MetaJson = "{"trigger":"" + trigger + ""}"
            });
        }

        var last = missed.Last();
        var next = rule.Type == ReminderType.Once ? DateTimeOffset.MaxValue : _engine.ComputeNextFromCursor(last, rule);

        var oldNext = state.NextOccurrenceUtcTicks;

        state.SeriesCursorLocal = last;
        state.SeriesCursorUtcTicks = last.ToUniversalTime().UtcTicks;

        state.NextOccurrenceLocal = next;
        state.NextOccurrenceUtcTicks = next == DateTimeOffset.MaxValue ? long.MaxValue : next.ToUniversalTime().UtcTicks;

        await _repo.AddAdjustmentAsync(new ReminderAdjustment
        {
            RuleId = rule.Id,
            OldNextUtcTicks = oldNext,
            NewNextUtcTicks = state.NextOccurrenceUtcTicks,
            Reason = "missed_compensation",
            Note = "mode=" + _catchUpMode.ToString()
        });

        await _repo.UpsertRuleAndStateAsync(rule, state);
    }
}

public interface IToastGateway
{
    Task ShowTaskToastAsync(string taskId, string ruleId, string occurrenceId, string content);
    Task ShowCoalescedAsync(int overdueCount);
}
