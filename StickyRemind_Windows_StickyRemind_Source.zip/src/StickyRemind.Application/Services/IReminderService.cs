using StickyRemind.Application.Dtos;

namespace StickyRemind.Application.Services;

public interface IReminderService
{
    Task UpsertRuleAsync(string taskId, ReminderRequest req);
    Task RemoveRuleAsync(string taskId);

    Task SnoozeAsync(string ruleId, TimeSpan delay, string reason);
    Task CompleteTaskFromRuleAsync(string ruleId);
    Task OpenTaskFromRuleAsync(string ruleId);

    // Background scheduler calls:
    Task RunSchedulerTickAsync();
    Task RunCatchUpAsync(string trigger);
}
