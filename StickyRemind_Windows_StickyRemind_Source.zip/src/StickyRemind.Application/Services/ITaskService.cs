using StickyRemind.Application.Dtos;
using StickyRemind.Application.Queries;

namespace StickyRemind.Application.Services;

public interface ITaskService
{
    Task<string> CreateAsync(CreateTaskRequest req);
    Task SetDoneAsync(string taskId, bool isDone);
    Task UpdateContentAsync(string taskId, string content);
    Task AssignTagsAsync(string taskId, List<string> tags);
    Task<List<TaskDto>> SearchAsync(TaskQuery query);
    Task DeleteAsync(string taskId);
}
