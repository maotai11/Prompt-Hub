using StickyRemind.Application.Dtos;
using StickyRemind.Application.Queries;
using StickyRemind.Domain.Entities;
using StickyRemind.Infrastructure.Repositories;

namespace StickyRemind.Application.Services;

public sealed class TaskService : ITaskService
{
    private readonly TaskRepository _tasks;
    private readonly TagRepository _tags;
    private readonly TaskTagRepository _taskTags;
    private readonly ReminderRepository _reminders;

    public TaskService(TaskRepository tasks, TagRepository tags, TaskTagRepository taskTags, ReminderRepository reminders)
    {
        _tasks = tasks;
        _tags = tags;
        _taskTags = taskTags;
        _reminders = reminders;
    }

    public async Task<string> CreateAsync(CreateTaskRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Content)) throw new ArgumentException("Content is empty.");

        var t = new TaskItem { Content = req.Content.Trim() };
        await _tasks.InsertAsync(t);

        var tagIds = new List<string>();
        foreach (var name in req.Tags.Select(NormalizeTag).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct())
        {
            var tag = await _tags.UpsertByNameAsync(name);
            tagIds.Add(tag.Id);
        }
        await _taskTags.ReplaceTagsAsync(t.Id, tagIds);

        return t.Id;
    }

    public async Task SetDoneAsync(string taskId, bool isDone) => await _tasks.SetDoneAsync(taskId, isDone);

    public async Task UpdateContentAsync(string taskId, string content) => await _tasks.UpdateContentAsync(taskId, content.Trim());

    public async Task AssignTagsAsync(string taskId, List<string> tags)
    {
        var tagIds = new List<string>();
        foreach (var name in tags.Select(NormalizeTag).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct())
        {
            var tag = await _tags.UpsertByNameAsync(name);
            tagIds.Add(tag.Id);
        }
        await _taskTags.ReplaceTagsAsync(taskId, tagIds);
    }

    public async Task<List<TaskDto>> SearchAsync(TaskQuery query)
    {
        var rows = await _tasks.SearchAsync(query.IncludeDone, query.SearchText, query.TagsAny?.Select(NormalizeTag).ToList());
        var list = new List<TaskDto>();
        foreach (var (t, tags) in rows)
        {
            var dto = new TaskDto
            {
                Id = t.Id,
                Content = t.Content,
                IsDone = t.IsDone,
                CreatedAtLocal = t.CreatedAtLocal,
                Tags = tags.ToList()
            };
            var rem = await _reminders.GetByTaskIdAsync(t.Id);
            if (rem != null && rem.Value.State.Status == ReminderStatus.Active)
            {
                dto.ReminderRuleId = rem.Value.Rule.Id;
                dto.NextReminderLocal = rem.Value.State.NextOccurrenceLocal;
                dto.ReminderType = rem.Value.Rule.Type.ToString();
            }
            list.Add(dto);
        }
        return list;
    }

    public async Task DeleteAsync(string taskId) => await _tasks.DeleteAsync(taskId);

    private static string NormalizeTag(string s)
    {
        s = (s ?? "").Trim();
        if (s.StartsWith("#")) s = s[1..];
        return s;
    }
}
