namespace StickyRemind.Application.Queries;

public sealed class TaskQuery
{
    public bool IncludeDone { get; set; }
    public string? SearchText { get; set; }
    public List<string> TagsAny { get; set; } = new();
}
