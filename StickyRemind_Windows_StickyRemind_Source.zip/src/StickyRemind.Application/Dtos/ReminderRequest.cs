namespace StickyRemind.Application.Dtos;

public sealed class ReminderRequest
{
    public string Type { get; set; } = "None"; // None|Once|Daily|Weekly|Interval
    public DateTimeOffset StartLocal { get; set; } = DateTimeOffset.Now;
    public TimeSpan? TimeOfDayLocal { get; set; }
    public int? WeeklyMask { get; set; }
    public int? IntervalDays { get; set; }
    public string? TimeZoneId { get; set; }
}
