namespace StickyRemind.Application.Dtos;

public sealed class TaskDto
{
    public string Id { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public bool IsDone { get; set; }

    public DateTimeOffset CreatedAtLocal { get; set; }

    public List<string> Tags { get; set; } = new();

    public string? ReminderRuleId { get; set; }
    public DateTimeOffset? NextReminderLocal { get; set; }
    public string? ReminderType { get; set; }
}
