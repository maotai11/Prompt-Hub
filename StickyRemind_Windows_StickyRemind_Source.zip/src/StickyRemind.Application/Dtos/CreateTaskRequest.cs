namespace StickyRemind.Application.Dtos;

public sealed class CreateTaskRequest
{
    public string Content { get; set; } = string.Empty;
    public List<string> Tags { get; set; } = new();

    public ReminderRequest? Reminder { get; set; }
}
