import { getSettings } from "./settings.js";
import { storage } from "./storage.js";

export function mountShell({ active }) {
  const links = [
    ["Home", "index.html", "home"],
    ["Settings", "settings.html", "settings"],
    ["Period", "period.html", "period"],
    ["ID Validator", "id-validator.html", "id"],
    ["Invoice Intake", "invoice-intake.html", "invoice"],
    ["Checklist", "checklist.html", "checklist"],
    ["Backup", "backup.html", "backup"],
    ["Ledger (stub)", "ledger.html", "ledger"],
    ["Payroll (stub)", "payroll.html", "payroll"],
    ["PDF Center (stub)", "pdf-center.html", "pdf"]
  ];
  const nav = links.map(([t, href, key]) =>
    `<a href="${href}" class="${key===active ? "active": ""}">${t}</a>`
  ).join("");

  const bannerEl = document.getElementById("storageBanner");
  const mode = storage.mode();
  if (bannerEl) {
    bannerEl.innerHTML = mode.ok
      ? `<div class="notice">Storage：<b>${mode.name}</b>（離線資料可持久保存）</div>`
      : `<div class="notice warn">Storage：<b>${mode.name}</b>（可能因 file:// 限制而降級；建議用 Chrome 啟動本機 http server 以確保 IndexedDB 可用）</div>`;
  }

  const topbar = document.getElementById("topbar");
  if (topbar) {
    topbar.innerHTML = `
      <div class="brand">
        <div class="logo"></div>
        <div>
          <div class="title">Offline Finance Ops Suite</div>
          <div class="sub">純前端離線 · 本機資料 · 會計/財務日常工具</div>
        </div>
      </div>
      <div class="nav">${nav}</div>
    `;
  }

  // Ensure settings exist (non-blocking).
  getSettings().catch(()=>{});
  storage.init().catch(()=>{});
}
