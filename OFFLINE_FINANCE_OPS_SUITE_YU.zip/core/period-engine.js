/**
 * Period Engine
 * Supports:
 * - week (weekStart)
 * - month (calendar month)
 * - customCutoff (cutoffDay e.g., 25 => 26~25)
 *
 * All dates are treated in local time; output ISO date (YYYY-MM-DD).
 */
function pad(n){ return String(n).padStart(2,"0"); }
function iso(d){
  const y=d.getFullYear(), m=pad(d.getMonth()+1), da=pad(d.getDate());
  return `${y}-${m}-${da}`;
}
function dateOnly(d){ return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function addDays(d, days){ const x=new Date(d); x.setDate(x.getDate()+days); return x; }

export function getPeriod(inputDate, { periodType="month", weekStart=1, cutoffDay=25 }={}){
  const d = (inputDate instanceof Date) ? dateOnly(inputDate) : dateOnly(new Date(inputDate));
  if (Number.isNaN(d.getTime())) throw new Error("Invalid date");

  if (periodType==="month"){
    const start = new Date(d.getFullYear(), d.getMonth(), 1);
    const end = new Date(d.getFullYear(), d.getMonth()+1, 0);
    const id = `${d.getFullYear()}${pad(d.getMonth()+1)}`;
    return { periodType, id, start: iso(start), end: iso(end), prev: shiftMonth(d,-1), next: shiftMonth(d,1) };
  }

  if (periodType==="week"){
    const dow = d.getDay(); // 0 Sun
    const diff = (dow - weekStart + 7) % 7;
    const start = addDays(d, -diff);
    const end = addDays(start, 6);
    const id = `${start.getFullYear()}W${pad(weekNumber(start, weekStart))}`;
    return { periodType, id, start: iso(start), end: iso(end), prev: getPeriod(addDays(start,-7), {periodType, weekStart}), next: getPeriod(addDays(start,7), {periodType, weekStart}) };
  }

  if (periodType==="customCutoff"){
    const cd = Math.max(1, Math.min(28, Number(cutoffDay)||25)); // keep safe
    // Definition: period is (cutoffDay+1 of prev month) -> cutoffDay of this month
    // Determine anchor month based on date position relative to cutoffDay.
    const y = d.getFullYear();
    const m = d.getMonth(); // 0-based
    const day = d.getDate();
    let endY=y, endM=m;
    if (day > cd){
      // ends next month cutoff
      const tmp = new Date(y, m+1, 1);
      endY = tmp.getFullYear(); endM = tmp.getMonth();
    }
    const end = new Date(endY, endM, cd);
    const start = addDays(new Date(endY, endM-1, cd), 1); // end prev month cutoff +1
    // period id: end month is the label, sortable
    const id = `C${endY}${pad(endM+1)}D${pad(cd)}`; 
    const prevDate = addDays(start, -1);
    const nextDate = addDays(end, 1);
    return { periodType, id, start: iso(start), end: iso(end), prev: getPeriod(prevDate, {periodType, cutoffDay: cd}), next: getPeriod(nextDate, {periodType, cutoffDay: cd}) };
  }

  throw new Error("Unknown periodType");
}

function shiftMonth(d, delta){
  const x = new Date(d.getFullYear(), d.getMonth()+delta, 15);
  return getPeriod(x, { periodType:"month" });
}

function weekNumber(date, weekStart){
  // Simple week number within year for display (not ISO-8601 strict).
  const yearStart = new Date(date.getFullYear(), 0, 1);
  const yearStartDow = yearStart.getDay();
  const offset = (yearStartDow - weekStart + 7) % 7;
  const firstWeekStart = addDays(yearStart, -offset);
  const diffDays = Math.floor((dateOnly(date) - firstWeekStart) / 86400000);
  return Math.floor(diffDays / 7) + 1;
}
