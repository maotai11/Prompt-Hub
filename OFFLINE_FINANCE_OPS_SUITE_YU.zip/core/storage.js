/**
 * Storage layer:
 * - Prefer IndexedDB (persistent, structured)
 * - Fallback to localStorage JSON per store if IndexedDB blocked (common under file:// in some browsers)
 */
const DB_NAME = "ofos_db";
const DB_VER = 1;
const STORES = ["settings_profile","docs_raw","docs_fields","entities_registry","checklist_rules","checklist_instances","audit_log","meta_recent"];

function idbAvailable() {
  return typeof indexedDB !== "undefined";
}

let _mode = { name: "Unknown", ok: false };
let _db = null;
let _fallback = false;

function lsKey(store){ return `ofos:${store}`; }
function lsLoad(store){
  try { return JSON.parse(localStorage.getItem(lsKey(store)) || "[]"); } catch { return []; }
}
function lsSave(store, rows){
  localStorage.setItem(lsKey(store), JSON.stringify(rows));
}

async function openDB() {
  if (!idbAvailable()) throw new Error("IndexedDB not available");

  return await new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of STORES){
        if (!db.objectStoreNames.contains(s)){
          const os = db.createObjectStore(s, { keyPath: "id" });
          os.createIndex("updatedAt", "updatedAt", { unique:false });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IDB open error"));
  });
}

function tx(store, mode="readonly"){
  const t = _db.transaction(store, mode);
  return t.objectStore(store);
}

async function idbAll(store){
  return await new Promise((resolve, reject)=>{
    const r = tx(store).getAll();
    r.onsuccess=()=>resolve(r.result||[]);
    r.onerror=()=>reject(r.error);
  });
}
async function idbPut(store, row){
  return await new Promise((resolve, reject)=>{
    const r = tx(store, "readwrite").put(row);
    r.onsuccess=()=>resolve(true);
    r.onerror=()=>reject(r.error);
  });
}
async function idbDel(store, id){
  return await new Promise((resolve, reject)=>{
    const r = tx(store, "readwrite").delete(id);
    r.onsuccess=()=>resolve(true);
    r.onerror=()=>reject(r.error);
  });
}

function uuid(){
  return (crypto?.randomUUID?.() || `id_${Date.now()}_${Math.random().toString(16).slice(2)}`);
}

export const storage = {
  async init(){
    if (_db || _fallback) return;
    try{
      _db = await openDB();
      _mode = { name:"IndexedDB", ok:true };
    }catch(e){
      _fallback = true;
      _mode = { name:"localStorage (fallback)", ok:false };
      // ensure keys exist
      for (const s of STORES){
        if (!localStorage.getItem(lsKey(s))) localStorage.setItem(lsKey(s), "[]");
      }
    }
  },
  mode(){ return _mode; },
  stores(){ return [...STORES]; },

  async all(store){
    await this.init();
    if (_fallback) return lsLoad(store);
    return await idbAll(store);
  },
  async put(store, row){
    await this.init();
    const now = new Date().toISOString();
    const next = { ...row };
    if (!next.id) next.id = uuid();
    if (!next.createdAt) next.createdAt = now;
    next.updatedAt = now;
    if (_fallback){
      const rows = lsLoad(store);
      const idx = rows.findIndex(r=>r.id===next.id);
      if (idx>=0) rows[idx]=next; else rows.unshift(next);
      lsSave(store, rows);
      return next;
    }
    await idbPut(store, next);
    return next;
  },
  async del(store, id){
    await this.init();
    if (_fallback){
      const rows = lsLoad(store).filter(r=>r.id!==id);
      lsSave(store, rows);
      return true;
    }
    return await idbDel(store, id);
  },
  async clearAll(){
    await this.init();
    if (_fallback){
      for (const s of STORES) localStorage.setItem(lsKey(s), "[]");
      return true;
    }
    // Clear each store
    for (const s of STORES){
      await new Promise((resolve, reject)=>{
        const t = _db.transaction(s, "readwrite");
        const os = t.objectStore(s);
        const r = os.clear();
        r.onsuccess=()=>resolve(true);
        r.onerror=()=>reject(r.error);
      });
    }
    return true;
  }
};
