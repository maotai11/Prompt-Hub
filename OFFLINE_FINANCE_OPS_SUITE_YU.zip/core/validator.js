/**
 * Taiwan Validators
 * - UBN (統一編號) checksum
 * - ROC ID (身分證字號/統一證號格式校驗基礎版)
 *
 * Note:
 * - UBN: 8 digits, weights [1,2,1,2,1,2,4,1]
 *   sum of digit products' digits; valid if sum % 10 === 0
 *   special case: if 7th digit is 7, sum+1 %10===0 also valid
 * - ROC ID: Letter mapping + digits; checksum method
 */
const UBN_W = [1,2,1,2,1,2,4,1];
const ROC_MAP = {
  A:10,B:11,C:12,D:13,E:14,F:15,G:16,H:17,I:34,J:18,K:19,L:20,M:21,N:22,O:35,P:23,Q:24,R:25,S:26,T:27,U:28,V:29,W:32,X:30,Y:31,Z:33
};

function sumDigits(n){
  return String(n).split("").reduce((a,c)=>a+Number(c),0);
}

export function validateUBN(input){
  const s = String(input||"").trim();
  if (!/^[0-9]{8}$/.test(s)) return { ok:false, reason:"格式需為 8 碼數字" };
  const digits = s.split("").map(Number);
  let sum = 0;
  for (let i=0;i<8;i++){
    sum += sumDigits(digits[i] * UBN_W[i]);
  }
  const ok = (sum % 10 === 0) || (digits[6]===7 && ((sum+1)%10===0));
  return ok ? { ok:true } : { ok:false, reason:"檢核碼不通過" };
}

export function validateRocId(input){
  const s = String(input||"").trim().toUpperCase();
  if (!/^[A-Z][0-9]{9}$/.test(s)) return { ok:false, reason:"格式需為 1 碼英文 + 9 碼數字" };
  const letter = s[0];
  const code = ROC_MAP[letter];
  if (!code) return { ok:false, reason:"英文字母不在對照表" };
  const n1 = Math.floor(code/10);
  const n2 = code % 10;
  const d = s.slice(1).split("").map(Number);
  // second digit: 1/2 (citizen), 8/9 (resident certificate variants)
  if (![1,2,8,9].includes(d[0])) return { ok:false, reason:"第 2 碼性別/類別碼不合法" };
  // weights: n1*1 + n2*9 + d1*8 + d2*7 + ... + d7*1 + d8*1
  const weights = [8,7,6,5,4,3,2,1,1];
  let sum = n1*1 + n2*9;
  for (let i=0;i<9;i++) sum += d[i]*weights[i];
  const ok = (sum % 10 === 0);
  return ok ? { ok:true } : { ok:false, reason:"檢核碼不通過" };
}

export function validateDateISO(s){
  const t = String(s||"").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return { ok:false, reason:"日期格式需為 YYYY-MM-DD" };
  const d = new Date(t+"T00:00:00");
  if (Number.isNaN(d.getTime())) return { ok:false, reason:"日期無效" };
  return { ok:true };
}

export function validateAmount(n){
  const v = Number(n);
  if (!Number.isFinite(v)) return { ok:false, reason:"金額需為數字" };
  if (v < 0) return { ok:false, reason:"金額不得為負" };
  return { ok:true };
}
