import { storage } from "./storage.js";

const DEFAULTS = {
  companyName: "（未設定）",
  companyUBN: "",
  periodType: "customCutoff", // week | month | customCutoff
  weekStart: 1, // 0=Sun ... 6=Sat, default Mon
  cutoffDay: 25, // for customCutoff
  exportNameRule: "OFOS_{tool}_{periodId}_{YYYYMMDD_HHmm}",
};

export async function getSettings(){
  await storage.init();
  const rows = await storage.all("settings_profile");
  if (rows.length) return rows[0].data;
  const seed = await storage.put("settings_profile", { id:"settings", data: DEFAULTS });
  return seed.data;
}

export async function saveSettings(data){
  await storage.init();
  return await storage.put("settings_profile", { id:"settings", data });
}
