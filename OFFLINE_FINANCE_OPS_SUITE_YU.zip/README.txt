Offline Finance Ops Suite (OFOS) - 離線會計/財務日常工具套件（核心版）

你得到的是：
- Home 控制台（index.html）
- Settings 設定中心（settings.html）
- Period 期別中心（period.html）
- ID Validator 統編/身分證檢核 + 名單（id-validator.html）
- Invoice Intake 單據收納與欄位化（invoice-intake.html）
- Checklist 每期核對清單（checklist.html）
- Backup 備份/還原（backup.html）
- Ledger/Payroll/PDF 先提供 stub（後續可把你現有工具整合進來）

如何使用（建議兩種）：
A) 直接 file:// 開啟
- 直接點開 index.html
- 注意：部分瀏覽器可能限制 IndexedDB；本套件會自動降級 localStorage。
- 若看到 Storage 警告屬正常（仍可用，但建議多做備份）。

B) 最穩定：本機 http server（強烈建議）
- Windows 在資料夾空白處 Shift+右鍵 → 在此處開啟 PowerShell
- 執行：python -m http.server 8080
- 用瀏覽器開：http://127.0.0.1:8080/

備份：
- 到 Backup 頁匯出 JSON
- 有任何問題，把備份檔留著，方便排查/還原

安全：
- 全部純前端、零外連、資料只在本機（IndexedDB/localStorage），匯出備份也是你手動下載。
