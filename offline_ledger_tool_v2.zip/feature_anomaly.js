(function(){
  const U=AppUtils;

  function median(arr){
    if(!arr.length) return 0;
    const a=[...arr].sort((x,y)=>x-y);
    const mid=Math.floor(a.length/2);
    return a.length%2? a[mid] : (a[mid-1]+a[mid])/2;
  }

  function mad(arr){
    const m=median(arr);
    const dev=arr.map(x=>Math.abs(x-m));
    return median(dev) || 1;
  }

  function mount(ctx){
    const root=ctx.mountPoint;
    root.innerHTML = `
      <div class="card">
        <div class="small">3-1：以穩健統計（MAD）偵測離群值。3-2：摘要相似度≥門檻且金額相同，視為疑似重複（必進待確認）。</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <button class="btn" id="btnRun">開始偵測（已選項目）</button>
        </div>
      </div>
      <div class="card">
        <div class="field-label">3-1 離群值</div>
        <div id="outliers"></div>
      </div>
      <div class="card">
        <div class="field-label">3-2 近似重複（待確認）</div>
        <div id="dupes"></div>
      </div>
    `;
    const el = {
      btnRun: root.querySelector('#btnRun'),
      outliers: root.querySelector('#outliers'),
      dupes: root.querySelector('#dupes')
    };

    function renderOutliers(list){
      if(!list.length){ el.outliers.innerHTML='<div class="small">無</div>'; return; }
      const rows = list.map(x=>`<tr>
        <td class="mono">${U.escapeHtml(x.date)}</td>
        <td class="mono">${U.escapeHtml(x.voucherNo||'')}</td>
        <td>${U.escapeHtml(x.summary||'')}</td>
        <td>${x.signedAmount<0?`<span class="bad mono">(${U.fmtMoney(x.signedAmount)})</span>`:`<span class="mono">${U.fmtMoney(x.signedAmount)}</span>`}</td>
        <td class="mono">${x.score.toFixed(2)}</td>
      </tr>`).join('');
      el.outliers.innerHTML = `<table class="table"><thead><tr><th>日期</th><th>票號</th><th>摘要</th><th>金額</th><th>離群分數</th></tr></thead><tbody>${rows}</tbody></table>`;
    }

    function renderDupes(pairs){
      if(!pairs.length){ el.dupes.innerHTML='<div class="small">無</div>'; return; }
      const blocks = pairs.map((p,idx)=>{
        return `<div class="group">
          <div class="group-head">
            <div>
              <div class="group-title">疑似重複 #${idx+1} <span class="chip mono">金額 ${U.fmtMoney(p.a.signedAmount)}</span></div>
              <div class="group-sub">相似度：${Math.round(p.sim*100)}%</div>
            </div>
          </div>
          <table class="table" style="margin-top:10px">
            <thead><tr><th>欄位</th><th>A</th><th>B</th></tr></thead>
            <tbody>
              <tr><td>日期</td><td class="mono">${U.escapeHtml(p.a.date)}</td><td class="mono">${U.escapeHtml(p.b.date)}</td></tr>
              <tr><td>票號</td><td class="mono">${U.escapeHtml(p.a.voucherNo||'')}</td><td class="mono">${U.escapeHtml(p.b.voucherNo||'')}</td></tr>
              <tr><td>摘要</td><td>${U.escapeHtml(p.a.summary||'')}</td><td>${U.escapeHtml(p.b.summary||'')}</td></tr>
            </tbody>
          </table>
        </div>`;
      }).join('');
      el.dupes.innerHTML = blocks;
    }

    el.btnRun.addEventListener('click', ()=>{
      const item = ctx.getSelectedItem();
      if(!item) return;
      const vals = item.entries.map(e=>e.signedAmount);
      const med = median(vals);
      const m = mad(vals);
      const out = item.entries.map(e=>{
        const score = Math.abs(e.signedAmount - med) / m;
        return {...e, score};
      }).filter(x=>x.score>=6).sort((a,b)=>b.score-a.score).slice(0,80);

      // dupes: O(n^2) limited
      const thr = ctx.settings.matching.similarityThreshold || 0.85;
      const pairs = [];
      const ents = item.entries;
      for(let i=0;i<ents.length;i++){
        for(let j=i+1;j<ents.length;j++){
          if(ents[i].signedAmount !== ents[j].signedAmount) continue;
          const sim = U.similarity(ents[i].summary, ents[j].summary);
          if(sim>=thr){
            pairs.push({a:ents[i], b:ents[j], sim});
            if(pairs.length>=50) break;
          }
        }
        if(pairs.length>=50) break;
      }

      renderOutliers(out);
      renderDupes(pairs);
      ctx.setOutputHint('已完成異常偵測（僅顯示前 80 筆離群 / 50 組疑似重複）。');
    });

    return {onItemChanged: ()=>{ el.outliers.innerHTML=''; el.dupes.innerHTML=''; }};
  }

  window.FeatureAnomaly = {mount};
})();