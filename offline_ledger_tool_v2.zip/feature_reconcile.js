(function(){
  const U=AppUtils;

  function mount(ctx){
    const root=ctx.mountPoint;
    root.innerHTML = `
      <div class="card">
        <div class="small">規則：先做 1v1（摘要近似 + 金額相同），再做確認區（摘要中文字相同但數字不同），最後做多對多候選（摘要雷同 + 可湊齊）。所有結果都可移動/撤銷。</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <button class="btn" id="btnRun">開始沖銷（已選項目）</button>
        </div>
      </div>

      <div class="card"><div class="field-label">沖銷區（已匹配）</div><div id="matched"></div></div>
      <div class="card"><div class="field-label">確認區（需勾選）</div><div id="confirm"></div></div>
      <div class="card">
        <div class="field-label">未沖銷（可再用數字池找組合）</div>
        <div class="card-row">
          <div class="field"><div class="field-label">目標數字</div><input id="target" type="number" placeholder="例如 6935" /></div>
          <div class="field" style="min-width:160px;flex:0 0 160px"><button class="btn" id="btnPool" style="width:100%">在未沖銷中找組合</button></div>
        </div>
        <div id="unmatched"></div>
        <div id="poolResults"></div>
      </div>
    `;
    const el = {
      btnRun: root.querySelector('#btnRun'),
      matched: root.querySelector('#matched'),
      confirm: root.querySelector('#confirm'),
      unmatched: root.querySelector('#unmatched'),
      target: root.querySelector('#target'),
      btnPool: root.querySelector('#btnPool'),
      poolResults: root.querySelector('#poolResults')
    };

    function keySig(e){
      // remove digits for confirm-zone matching
      return U.normText(String(e.summary||'')).replace(/\d+/g,'#');
    }

    function run(item){
      const thr = ctx.settings.matching.similarityThreshold || 0.85;
      const ents = item.entries;

      const matched = [];
      const confirm = [];
      const used = new Set();

      // 1v1: find pairs with same abs amount and summary similarity
      for(let i=0;i<ents.length;i++){
        if(used.has(ents[i].entryKey)) continue;
        for(let j=i+1;j<ents.length;j++){
          if(used.has(ents[j].entryKey)) continue;
          if(Math.abs(ents[i].signedAmount) !== Math.abs(ents[j].signedAmount)) continue;
          // require opposite signs to reconcile
          if(ents[i].signedAmount * ents[j].signedAmount >= 0) continue;

          const sim = U.similarity(ents[i].summary, ents[j].summary);
          if(sim>=thr){
            matched.push({a:ents[i], b:ents[j], sim});
            used.add(ents[i].entryKey); used.add(ents[j].entryKey);
            break;
          }
        }
      }

      // confirm zone: same amount opposite sign, but text (without digits) equal, while full text not equal
      for(let i=0;i<ents.length;i++){
        if(used.has(ents[i].entryKey)) continue;
        for(let j=i+1;j<ents.length;j++){
          if(used.has(ents[j].entryKey)) continue;
          if(Math.abs(ents[i].signedAmount) !== Math.abs(ents[j].signedAmount)) continue;
          if(ents[i].signedAmount * ents[j].signedAmount >= 0) continue;

          const sigA = keySig(ents[i]);
          const sigB = keySig(ents[j]);
          if(sigA && sigA===sigB && U.normText(ents[i].summary)!==U.normText(ents[j].summary)){
            confirm.push({a:ents[i], b:ents[j]});
            used.add(ents[i].entryKey); used.add(ents[j].entryKey);
            break;
          }
        }
      }

      const unmatched = ents.filter(e=>!used.has(e.entryKey));
      return {matched, confirm, unmatched};
    }

    function renderPairs(container, pairs, withCheck){
      if(!pairs.length){ container.innerHTML='<div class="small">無</div>'; return; }
      container.innerHTML = pairs.map((p,idx)=>{
        const a=p.a, b=p.b;
        const chk = withCheck ? `<label class="chip"><input type="checkbox" data-idx="${idx}" /> 勾選成立</label>` : '';
        return `<div class="group">
          <div class="group-head">
            <div>
              <div class="group-title">#${idx+1} <span class="chip mono">金額 ${U.fmtMoney(a.signedAmount)} / ${U.fmtMoney(b.signedAmount)}</span></div>
              ${p.sim!=null?`<div class="group-sub">相似度：${Math.round(p.sim*100)}%</div>`:''}
            </div>
            <div style="display:flex;gap:8px;align-items:center">${chk}</div>
          </div>
          <table class="table" style="margin-top:10px">
            <thead><tr><th></th><th>日期</th><th>票號</th><th>摘要</th><th>金額</th></tr></thead>
            <tbody>
              <tr><td>A</td><td class="mono">${U.escapeHtml(a.date)}</td><td class="mono">${U.escapeHtml(a.voucherNo||'')}</td><td>${U.escapeHtml(a.summary||'')}</td><td>${a.signedAmount<0?`<span class="bad mono">(${U.fmtMoney(a.signedAmount)})</span>`:`<span class="mono">${U.fmtMoney(a.signedAmount)}</span>`}</td></tr>
              <tr><td>B</td><td class="mono">${U.escapeHtml(b.date)}</td><td class="mono">${U.escapeHtml(b.voucherNo||'')}</td><td>${U.escapeHtml(b.summary||'')}</td><td>${b.signedAmount<0?`<span class="bad mono">(${U.fmtMoney(b.signedAmount)})</span>`:`<span class="mono">${U.fmtMoney(b.signedAmount)}</span>`}</td></tr>
            </tbody>
          </table>
        </div>`;
      }).join('');
    }

    function renderUnmatched(container, list){
      if(!list.length){ container.innerHTML='<div class="small">無</div>'; return; }
      const rows = list.map(e=>{
        const amt=e.signedAmount;
        const amtHtml = amt<0 ? `<span class="bad mono">(${U.fmtMoney(amt)})</span>` : `<span class="mono">${U.fmtMoney(amt)}</span>`;
        return `<tr><td class="mono">${U.escapeHtml(e.date)}</td><td class="mono">${U.escapeHtml(e.voucherNo||'')}</td><td>${U.escapeHtml(e.summary||'')}</td><td>${amtHtml}</td></tr>`;
      }).join('');
      container.innerHTML = `<table class="table"><thead><tr><th>日期</th><th>票號</th><th>摘要</th><th>金額</th></tr></thead><tbody>${rows}</tbody></table>`;
    }

    function subsetSum(entries, target, limit){
      const sorted=[...entries].sort((a,b)=>Math.abs(b.signedAmount)-Math.abs(a.signedAmount));
      const results=[];
      const used=new Set();
      function dfs(start,sum,chosen){
        if(results.length>=limit) return;
        if(sum===target){ results.push([...chosen]); return; }
        for(let i=start;i<sorted.length;i++){
          const e=sorted[i];
          if(used.has(e.entryKey)) continue;
          chosen.push(e); used.add(e.entryKey);
          dfs(i+1,sum+e.signedAmount,chosen);
          chosen.pop(); used.delete(e.entryKey);
          if(results.length>=limit) return;
        }
      }
      dfs(0,0,[]);
      return results;
    }

    let last = null;

    el.btnRun.addEventListener('click', ()=>{
      const item = ctx.getSelectedItem();
      if(!item) return;
      last = run(item);
      renderPairs(el.matched, last.matched, false);
      renderPairs(el.confirm, last.confirm, true);
      renderUnmatched(el.unmatched, last.unmatched);
      el.poolResults.innerHTML='';
      ctx.setOutputHint('已完成初步沖銷：確認區需勾選才算成立。未沖銷可再用數字池找組合。');
    });

    el.btnPool.addEventListener('click', ()=>{
      if(!last) return;
      const target = Number(el.target.value||0);
      const combos = subsetSum(last.unmatched, target, 50);
      if(!combos.length){ el.poolResults.innerHTML='<div class="small">找不到組合</div>'; return; }
      el.poolResults.innerHTML = combos.map((combo,idx)=>{
        const sum = combo.reduce((s,e)=>s+e.signedAmount,0);
        const rows = combo.map(e=>`<tr><td class="mono">${U.escapeHtml(e.date)}</td><td class="mono">${U.escapeHtml(e.voucherNo||'')}</td><td>${U.escapeHtml(e.summary||'')}</td><td class="mono">${U.fmtMoney(e.signedAmount)}</td></tr>`).join('');
        return `<div class="group">
          <div class="group-head">
            <div><div class="group-title">候選 #${idx+1} <span class="chip mono">${U.fmtMoney(sum)} / ${U.fmtMoney(target)}</span></div><div class="group-sub">筆數：${combo.length}</div></div>
            <button class="btn" data-pick="${idx}">送到輸出</button>
          </div>
          <table class="table" style="margin-top:10px"><thead><tr><th>日期</th><th>票號</th><th>摘要</th><th>金額</th></tr></thead><tbody>${rows}</tbody></table>
        </div>`;
      }).join('');
      el.poolResults.querySelectorAll('[data-pick]').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const idx=parseInt(btn.getAttribute('data-pick'),10);
          const combo=combos[idx];
          const sum=combo.reduce((s,e)=>s+e.signedAmount,0);
          const item=ctx.getSelectedItem();
          const text=combo.map(e=>`${e.summary}(${U.fmtMoney(e.signedAmount)})`).join('、');
          ctx.setOutputText(`未沖銷：${text}`);
          ctx.setOutputHint(sum===target?'OK：輸出加總等於目標。':'警示：輸出加總不等於目標。');
        });
      });
    });

    return {onItemChanged: ()=>{ last=null; el.matched.innerHTML=''; el.confirm.innerHTML=''; el.unmatched.innerHTML=''; el.poolResults.innerHTML=''; }};
  }

  window.FeatureReconcile = {mount};
})();