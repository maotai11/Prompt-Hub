(function(){
  const U=AppUtils;

  function buildUI(root){
    root.innerHTML = `
      <div class="card">
        <div class="kpi">
          <div class="box"><div class="k">Target（期末餘額）</div><div class="v mono" id="kpiTarget">-</div></div>
          <div class="box"><div class="k">Current（分組加總）</div><div class="v mono" id="kpiCurrent">-</div></div>
          <div class="box"><div class="k">Diff</div><div class="v mono" id="kpiDiff">-</div></div>
        </div>
        <div class="small">提示：先「預覽分組」再確認。若命中多組，會以權重最高者唯一歸屬；未命中者歸入「其他」。</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <button class="btn" id="btnPreview">預覽分組</button>
          <button class="btn btn-ghost" id="btnApply" disabled>確認套用</button>
          <button class="btn btn-ghost" id="btnReset" disabled>撤銷到原始</button>
        </div>
      </div>

      <div class="card">
        <div class="field-label">明細（可單/複選後移動群組或刪除）</div>
        <div id="entryTable"></div>
      </div>

      <div class="card">
        <div class="field-label">分組結果（展開/收合）</div>
        <div id="groups"></div>
      </div>
    `;
  }

  function renderEntries(container, entries, state){
    const rows = entries.map((e, idx)=>{
      const amt = e.signedAmount;
      const amtHtml = amt<0 ? `<span class="bad mono">(${U.fmtMoney(amt)})</span>` : `<span class="mono">${U.fmtMoney(amt)}</span>`;
      return `<tr>
        <td class="mono"><input type="checkbox" data-ek="${U.escapeHtml(e.entryKey)}" ${state.deletedKeys.has(e.entryKey)?'disabled':''}/> ${U.escapeHtml(e.date)}</td>
        <td class="mono">${U.escapeHtml(e.voucherNo||'')}</td>
        <td>${U.escapeHtml(e.summary||'')}</td>
        <td>${amtHtml}</td>
        <td class="mono">${U.fmtMoney(e.balance||0)}</td>
        <td><span class="chip">${U.escapeHtml(state.assignments[e.entryKey]||'')}</span></td>
      </tr>`;
    }).join('');
    container.innerHTML = `
      <table class="table">
        <thead><tr>
          <th>日期</th><th>傳票號碼</th><th>摘要</th><th>金額（依借/貸正負）</th><th>餘額</th><th>群組</th>
        </tr></thead>
        <tbody>${rows || `<tr><td colspan="6" class="small">無明細</td></tr>`}</tbody>
      </table>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
        <select id="moveToGroup">
          <option value="">移動到群組…</option>
        </select>
        <button class="btn btn-ghost" id="btnMove" disabled>移動（套用到已勾選）</button>
        <button class="btn btn-ghost" id="btnDelete" disabled>刪除（從計算排除）</button>
      </div>
      <div class="small" style="margin-top:8px">刪除只影響本次分析（可撤銷）。</div>
    `;
  }

  function computeGroups(entries, keywordGroups, defaultName){
    // returns {assignments, groups:{name:{sum, entries}}}
    const assignments = {};
    const groups = {};
    const lib = (keywordGroups||[]).flatMap(g=>{
      return (g.keywords||[]).map(k=>({groupName:g.name, text:k.text, weight:k.weight||0, mode:k.mode||'like'}));
    });

    for(const e of entries){
      let best = null;
      for(const rule of lib){
        const s = U.normText(e.summary||'');
        const t = U.normText(rule.text||'');
        if(!t) continue;
        let ok=false;
        if(rule.mode==='='){
          ok = (s===t);
        }else{
          ok = s.includes(t);
        }
        if(ok){
          if(!best || rule.weight>best.weight){
            best = rule;
          }
        }
      }
      const gname = best?best.groupName:defaultName;
      assignments[e.entryKey] = gname;

      if(!groups[gname]) groups[gname] = {name:gname, sum:0, entries:[]};
      groups[gname].sum += e.signedAmount;
      groups[gname].entries.push(e);
    }
    return {assignments, groups};
  }

  function renderGroups(container, groups){
    const names = Object.keys(groups||{}).sort((a,b)=> a.localeCompare(b,'zh-Hant'));
    container.innerHTML = names.map(name=>{
      const g=groups[name];
      const rows = g.entries.map(e=>{
        const amt = e.signedAmount;
        const amtHtml = amt<0 ? `<span class="bad mono">(${U.fmtMoney(amt)})</span>` : `<span class="mono">${U.fmtMoney(amt)}</span>`;
        return `<tr>
          <td class="mono">${U.escapeHtml(e.date)}</td>
          <td class="mono">${U.escapeHtml(e.voucherNo||'')}</td>
          <td>${U.escapeHtml(e.summary||'')}</td>
          <td>${amtHtml}</td>
        </tr>`;
      }).join('');
      return `
        <div class="group">
          <div class="group-head">
            <div>
              <div class="group-title">${U.escapeHtml(name)} <span class="chip mono">${U.fmtMoney(g.sum)}</span></div>
              <div class="group-sub">筆數：${g.entries.length}</div>
            </div>
            <button class="btn btn-ghost" data-toggle="${U.escapeHtml(name)}">展開/收合</button>
          </div>
          <div id="g_${U.escapeHtml(name)}" style="margin-top:10px;display:none">
            <table class="table">
              <thead><tr><th>日期</th><th>票號</th><th>摘要</th><th>金額</th></tr></thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </div>
      `;
    }).join('') || `<div class="small">尚未分組</div>`;

    container.querySelectorAll('[data-toggle]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const name = btn.getAttribute('data-toggle');
        const box = container.querySelector('#g_'+CSS.escape(name));
        if(!box) return;
        box.style.display = (box.style.display==='none') ? 'block':'none';
      });
    });
  }

  function calcKPI(target, current){
    const diff = (target||0) - (current||0);
    return {target, current, diff};
  }

  function buildOutput(item, groups){
    const parts = [];
    const names = Object.keys(groups||{}).sort((a,b)=>a.localeCompare(b,'zh-Hant'));
    for(const name of names){
      parts.push(`${name}(${U.fmtMoney(groups[name].sum)})`);
    }
    return `${item.subjectCode} ${item.subjectName}(${item.drCr})：` + parts.join('、');
  }

  function mount(ctx){
    const root = ctx.mountPoint;
    buildUI(root);

    const el = {
      kpiTarget: root.querySelector('#kpiTarget'),
      kpiCurrent: root.querySelector('#kpiCurrent'),
      kpiDiff: root.querySelector('#kpiDiff'),
      btnPreview: root.querySelector('#btnPreview'),
      btnApply: root.querySelector('#btnApply'),
      btnReset: root.querySelector('#btnReset'),
      entryTable: root.querySelector('#entryTable'),
      groups: root.querySelector('#groups')
    };

    const state = {
      preview: null,
      applied: null,
      assignments: {},
      deletedKeys: new Set(),
      lastEntries: []
    };

    function updateKpi(item, groupsObj){
      const target = item?.endingBalance ?? 0;
      const current = Object.values(groupsObj||{}).reduce((s,g)=> s+g.sum, 0);
      const {diff} = calcKPI(target, current);
      el.kpiTarget.textContent = U.fmtMoney(target);
      el.kpiCurrent.textContent = U.fmtMoney(current);
      el.kpiDiff.innerHTML = diff===0 ? `<span class="good mono">${U.fmtMoney(diff)}</span>` : `<span class="warn mono">${U.fmtMoney(diff)}</span>`;
      ctx.setOutputHint(diff===0 ? 'OK：分組加總已對齊期末餘額。' : '提示：Diff 非 0，請調整分組/移動/刪除後再確認。');
    }

    function refreshEntryTable(item){
      const entries = item ? item.entries.filter(e=>!state.deletedKeys.has(e.entryKey)) : [];
      state.lastEntries = entries;
      renderEntries(el.entryTable, entries, state);

      // fill move-to groups
      const sel = el.entryTable.querySelector('#moveToGroup');
      const groupNames = Array.from(new Set(Object.values(state.assignments||{}))).filter(Boolean);
      sel.innerHTML = `<option value="">移動到群組…</option>` + groupNames.map(n=>`<option value="${U.escapeHtml(n)}">${U.escapeHtml(n)}</option>`).join('');

      const btnMove = el.entryTable.querySelector('#btnMove');
      const btnDelete = el.entryTable.querySelector('#btnDelete');
      const onSelChange = ()=>{
        const anyChecked = !!el.entryTable.querySelector('input[type=checkbox]:checked');
        btnMove.disabled = !(anyChecked && sel.value);
        btnDelete.disabled = !anyChecked;
      };
      el.entryTable.querySelectorAll('input[type=checkbox]').forEach(chk=>{
        chk.addEventListener('change', onSelChange);
      });
      sel.addEventListener('change', onSelChange);

      btnMove.addEventListener('click', ()=>{
        const targetGroup = sel.value;
        if(!targetGroup) return;
        el.entryTable.querySelectorAll('input[type=checkbox]:checked').forEach(chk=>{
          const ek = chk.getAttribute('data-ek');
          state.assignments[ek] = targetGroup;
        });
        // recompute group sums with manual assignments
        const groups = {};
        for(const e of entries){
          const gname = state.assignments[e.entryKey] || ctx.settings.groupRule.defaultGroupName;
          if(!groups[gname]) groups[gname]={name:gname,sum:0,entries:[]};
          groups[gname].sum += e.signedAmount;
          groups[gname].entries.push(e);
        }
        state.applied = groups;
        renderGroups(el.groups, groups);
        updateKpi(item, groups);
        ctx.setOutputText(buildOutput(item, groups));
        onSelChange();
      });

      btnDelete.addEventListener('click', ()=>{
        el.entryTable.querySelectorAll('input[type=checkbox]:checked').forEach(chk=>{
          state.deletedKeys.add(chk.getAttribute('data-ek'));
        });
        refreshEntryTable(item);
        // rebuild groups if applied
        if(state.applied){
          const entries2 = item.entries.filter(e=>!state.deletedKeys.has(e.entryKey));
          const groups = {};
          for(const e of entries2){
            const gname = state.assignments[e.entryKey] || ctx.settings.groupRule.defaultGroupName;
            if(!groups[gname]) groups[gname]={name:gname,sum:0,entries:[]};
            groups[gname].sum += e.signedAmount;
            groups[gname].entries.push(e);
          }
          state.applied = groups;
          renderGroups(el.groups, groups);
          updateKpi(item, groups);
          ctx.setOutputText(buildOutput(item, groups));
        }
      });
    }

    function onItemChanged(item){
      state.preview=null;
      state.applied=null;
      state.assignments={};
      state.deletedKeys=new Set();
      el.btnApply.disabled=true;
      el.btnReset.disabled=true;
      el.groups.innerHTML = `<div class="small">尚未分組</div>`;
      if(!item){ el.entryTable.innerHTML=''; return; }
      // default empty assignments
      for(const e of item.entries){
        state.assignments[e.entryKey] = '';
      }
      refreshEntryTable(item);
      updateKpi(item, {});
      ctx.setOutputText('');
    }

    el.btnPreview.addEventListener('click', ()=>{
      const item = ctx.getSelectedItem();
      if(!item) return;
      const entries = item.entries.filter(e=>!state.deletedKeys.has(e.entryKey));
      const res = computeGroups(entries, ctx.settings.keywordGroups, ctx.settings.groupRule.defaultGroupName);
      state.preview = res;
      state.assignments = res.assignments;
      renderGroups(el.groups, res.groups);
      updateKpi(item, res.groups);
      refreshEntryTable(item);
      el.btnApply.disabled=false;
      ctx.setOutputText(buildOutput(item, res.groups));
    });

    el.btnApply.addEventListener('click', ()=>{
      if(!state.preview) return;
      state.applied = state.preview.groups;
      el.btnReset.disabled=false;
      ctx.setOutputHint('已套用分組。你仍可在明細區移動群組或刪除，並立即更新 Diff。');
    });

    el.btnReset.addEventListener('click', ()=>{
      onItemChanged(ctx.getSelectedItem());
      ctx.setOutputHint('已撤銷到原始狀態。');
    });

    return {onItemChanged, update:()=>onItemChanged(ctx.getSelectedItem())};
  }

  window.FeatureGrouping = {mount};
})();