(function(){
  const U=AppUtils;

  function subsetSum(entries, target, limit){
    // backtracking with pruning; entries must be unique by entryKey
    const sorted = [...entries].sort((a,b)=> Math.abs(b.signedAmount)-Math.abs(a.signedAmount));
    const results = [];
    const used = new Set();
    function dfs(start, sum, chosen){
      if(results.length>=limit) return;
      if(sum===target){
        results.push([...chosen]);
        return;
      }
      for(let i=start;i<sorted.length;i++){
        const e=sorted[i];
        if(used.has(e.entryKey)) continue;
        const next = sum + e.signedAmount;

        // simple pruning (still allows negative)
        // if all remaining abs are too small and we already exceed target with same sign, skip
        chosen.push(e); used.add(e.entryKey);
        dfs(i+1, next, chosen);
        chosen.pop(); used.delete(e.entryKey);

        if(results.length>=limit) return;
      }
    }
    dfs(0,0,[]);
    return results;
  }

  function mount(ctx){
    const root=ctx.mountPoint;
    root.innerHTML = `
      <div class="card">
        <div class="card-row">
          <div class="field">
            <div class="field-label">目標數字（TargetAmount）</div>
            <input id="target" type="number" placeholder="例如 6935" />
          </div>
          <div class="field">
            <div class="field-label">回傳候選上限（避免爆量卡死）</div>
            <select id="limit">
              <option value="20">20</option>
              <option value="50" selected>50</option>
              <option value="100">100</option>
            </select>
          </div>
          <div class="field" style="min-width:160px;flex:0 0 160px">
            <button class="btn" id="btnRun" style="width:100%">開始搜尋</button>
          </div>
        </div>
        <div class="small">規則：同一筆明細不得重複使用（以日期/票號/摘要/借貸/餘額組合為 entryKey 去重）。</div>
      </div>
      <div class="card">
        <div class="field-label">候選組合（點選一組 → 送到輸出）</div>
        <div id="candidates"></div>
      </div>
    `;

    const el = {
      target: root.querySelector('#target'),
      limit: root.querySelector('#limit'),
      btnRun: root.querySelector('#btnRun'),
      candidates: root.querySelector('#candidates')
    };

    function renderCandidates(item, combos, target){
      if(!combos.length){
        el.candidates.innerHTML = `<div class="small">找不到候選組合</div>`;
        return;
      }
      el.candidates.innerHTML = combos.map((combo,idx)=>{
        const sum = combo.reduce((s,e)=>s+e.signedAmount,0);
        const rows = combo.map(e=>{
          const amt=e.signedAmount;
          const amtHtml = amt<0 ? `<span class="bad mono">(${U.fmtMoney(amt)})</span>` : `<span class="mono">${U.fmtMoney(amt)}</span>`;
          return `<tr><td class="mono">${U.escapeHtml(e.date)}</td><td class="mono">${U.escapeHtml(e.voucherNo||'')}</td><td>${U.escapeHtml(e.summary||'')}</td><td>${amtHtml}</td></tr>`;
        }).join('');
        return `
          <div class="group">
            <div class="group-head">
              <div>
                <div class="group-title">候選 #${idx+1} <span class="chip mono">合計 ${U.fmtMoney(sum)} / 目標 ${U.fmtMoney(target)}</span></div>
                <div class="group-sub">筆數：${combo.length}</div>
              </div>
              <button class="btn" data-pick="${idx}">選這組</button>
            </div>
            <div style="margin-top:10px">
              <table class="table">
                <thead><tr><th>日期</th><th>票號</th><th>摘要</th><th>金額</th></tr></thead>
                <tbody>${rows}</tbody>
              </table>
            </div>
          </div>
        `;
      }).join('');

      el.candidates.querySelectorAll('[data-pick]').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const idx = parseInt(btn.getAttribute('data-pick'),10);
          const combo = combos[idx];
          const sum = combo.reduce((s,e)=>s+e.signedAmount,0);
          const ok = (sum===target);
          const text = combo.map(e=>`${e.summary}(${U.fmtMoney(e.signedAmount)})`).join('、');
          ctx.setOutputText(`${item.subjectCode} ${item.subjectName}(${item.drCr})：${text}`);
          ctx.setOutputHint(ok ? 'OK：輸出加總等於目標。' : '警示：輸出加總不等於目標（不應發生）；請改選。');
        });
      });
    }

    el.btnRun.addEventListener('click', ()=>{
      const item = ctx.getSelectedItem();
      if(!item) return;
      const target = Number(el.target.value||0);
      const limit = parseInt(el.limit.value,10) || 50;
      const entries = item.entries;
      const combos = subsetSum(entries, target, limit);
      renderCandidates(item, combos, target);
    });

    return {
      onItemChanged: ()=>{
        el.candidates.innerHTML = `<div class="small">請輸入目標數字後開始搜尋</div>`;
      }
    };
  }

  window.FeaturePool = {mount};
})();