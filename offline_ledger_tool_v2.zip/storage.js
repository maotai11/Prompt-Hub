(function(){
  const KEY = {
    version: 'ledger:version',
    users: 'ledger:users',
    currentUser: 'ledger:currentUser',
    globalSettings: 'ledger:settings:global',
    userSettingsPrefix: 'ledger:settings:user:',
    uploadIndexPrefix: 'ledger:uploads:index:' // per-user array of {id, name, ts}
  };
  const VERSION = 1;

  function lsGet(k, def){
    try{
      const v = localStorage.getItem(k);
      return v? JSON.parse(v) : def;
    }catch(e){ return def; }
  }
  function lsSet(k, v){
    localStorage.setItem(k, JSON.stringify(v));
  }

  // IndexedDB for unlimited-ish storage (parsed uploads)
  const DB_NAME='ledger_db';
  const DB_VER=1;
  const STORE_UPLOADS='uploads';

  function openDB(){
    return new Promise((resolve,reject)=>{
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = (ev)=>{
        const db=req.result;
        if(!db.objectStoreNames.contains(STORE_UPLOADS)){
          db.createObjectStore(STORE_UPLOADS, {keyPath:'key'}); // key = userId|uploadId
        }
      };
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error);
    });
  }
  async function idbPutUpload(userId, uploadId, data){
    const db=await openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_UPLOADS,'readwrite');
      tx.objectStore(STORE_UPLOADS).put({key:`${userId}|${uploadId}`, userId, uploadId, data});
      tx.oncomplete=()=>resolve(true);
      tx.onerror=()=>reject(tx.error);
    });
  }
  async function idbGetUpload(userId, uploadId){
    const db=await openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_UPLOADS,'readonly');
      const req=tx.objectStore(STORE_UPLOADS).get(`${userId}|${uploadId}`);
      req.onsuccess=()=>resolve(req.result?req.result.data:null);
      req.onerror=()=>reject(req.error);
    });
  }
  async function idbDelUpload(userId, uploadId){
    const db=await openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_UPLOADS,'readwrite');
      tx.objectStore(STORE_UPLOADS).delete(`${userId}|${uploadId}`);
      tx.oncomplete=()=>resolve(true);
      tx.onerror=()=>reject(tx.error);
    });
  }

  const S = {};

  S.ensureVersion = ()=>{
    const v = lsGet(KEY.version, 0);
    if(v !== VERSION){
      lsSet(KEY.version, VERSION);
    }
  };

  S.listUsers = ()=> lsGet(KEY.users, []);
  S.addUser = (name)=>{
    name = AppUtils.normText(name);
    if(!name) return null;
    const users = S.listUsers();
    let u = users.find(x=>x.name===name);
    if(!u){
      u = {id: 'u_'+Math.random().toString(36).slice(2,10), name, createdAt: Date.now()};
      users.push(u);
      lsSet(KEY.users, users);
    }
    lsSet(KEY.currentUser, u.id);
    return u;
  };
  S.getCurrentUserId = ()=> lsGet(KEY.currentUser, null);
  S.setCurrentUserId = (id)=> lsSet(KEY.currentUser, id);
  S.logout = ()=> { /* logout means just keep current user selectable; no deletion */ };

  S.getGlobalSettings = ()=> lsGet(KEY.globalSettings, null);
  S.setGlobalSettings = (obj)=> lsSet(KEY.globalSettings, obj);

  S.getUserUploadIndex = (userId)=> lsGet(KEY.uploadIndexPrefix+userId, []);
  S.setUserUploadIndex = (userId, arr)=> lsSet(KEY.uploadIndexPrefix+userId, arr);

  S.saveUploadForUser = async (userId, name, parsedData)=>{
    // keep only 2 uploads; 3rd overwrites oldest
    const idx = S.getUserUploadIndex(userId);
    const uploadId = 'up_'+Math.random().toString(36).slice(2,10);
    const item = {id: uploadId, name, ts: Date.now()};
    idx.push(item);
    idx.sort((a,b)=>a.ts-b.ts);
    while(idx.length>2){
      const oldest = idx.shift();
      await idbDelUpload(userId, oldest.id);
    }
    S.setUserUploadIndex(userId, idx);
    await idbPutUpload(userId, uploadId, parsedData);
    return item;
  };

  S.loadLatestUpload = async (userId)=>{
    const idx = S.getUserUploadIndex(userId);
    if(!idx.length) return null;
    const latest = [...idx].sort((a,b)=>b.ts-a.ts)[0];
    const data = await idbGetUpload(userId, latest.id);
    return {meta: latest, data};
  };

  S.loadUpload = async (userId, uploadId)=>{
    const data = await idbGetUpload(userId, uploadId);
    return data;
  };

  S.deleteUpload = async (userId, uploadId)=>{
    let idx = S.getUserUploadIndex(userId);
    idx = idx.filter(x=>x.id!==uploadId);
    S.setUserUploadIndex(userId, idx);
    await idbDelUpload(userId, uploadId);
    return true;
  };

  // Default settings per your ignore rules & matching modes
  S.defaultSettings = ()=>{
    return {
      ignore: {
        // exact line matches (normalized)
        exactAColumnLines: [
          "興漢塑膠有限公司",
          "分    類    帳"
        ],
        startsWithAColumn: [
          "製表日期",
          "期間：",
          "頁 次",
          "日期"
        ],
        ignoreMonthTotalPrefix: ["月計:"],
        ignoreAccumTotalPrefix: ["累計:"]
      },
      header: {
        // used for columnMap detection
        requiredHeaders: ["日期","摘要","借方金額","貸方金額","借/貸","餘額"],
        // repeated header rows after first page should be ignored
        ignoreRepeatedHeadersAfterFirst: true
      },
      matching: {
        similarityThreshold: 0.85, // 80~100%
        allowCharErrors: 2
      },
      keywordGroups: [
        // global keyword library (can be edited in settings)
        // {name:"車險", keywords:[{text:"汽車險", weight:10, mode:"like"}]}
      ],
      groupRule: {
        defaultGroupName: "其他"
      }
    };
  };

  window.AppStorage = {KEY, S};
})();