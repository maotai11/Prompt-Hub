(function(){
  const U = {};
  U.trim = (s)=> (s==null?"":String(s)).trim();
  U.normSpace = (s)=> U.trim(s).replace(/\s+/g,' ');
  U.normFullHalf = (s)=> {
    s = U.trim(s);
    // basic full-width to half-width for digits and punctuation
    return s.replace(/[！-～]/g, ch=> String.fromCharCode(ch.charCodeAt(0)-0xFEE0))
            .replace(/　/g,' ');
  };
  // Normalize common Excel-escaped line breaks (e.g., "_x000D_\n") and whitespace
  U.normText = (s)=> {
    if(s==null) return "";
    let t = String(s);
    // Excel sometimes exports embedded line breaks as "_x000D_\n"
    t = t.replace(/_x000D_/gi, ' ');
    t = t.replace(/[\r\n]+/g, ' ');
    return U.normSpace(U.normFullHalf(t));
  };
  U.isDateROC = (s)=> /^\d{3}-\d{2}-\d{2}$/.test(U.trim(s));
  U.parseROC = (s)=> {
    s = U.trim(s);
    if(!U.isDateROC(s)) return null;
    const [y,mo,d]=s.split('-').map(x=>parseInt(x,10));
    return {rocYear:y, month:mo, day:d, iso:`${y+1911}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`};
  };
  U.parseMoney = (v)=> {
    if(v==null || v==="") return 0;
    if(typeof v === 'number') return v;
    const s = String(v).replace(/,/g,'').trim();
    const n = Number(s);
    return Number.isFinite(n)?n:0;
  };
  U.fmtMoney = (n)=> {
    const sign = n<0?'-':'';
    const abs = Math.abs(Math.round(n));
    return sign + abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };
  U.escapeHtml = (s)=> String(s??'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');

  // Simple similarity: normalized Levenshtein ratio
  U.levenshtein = (a,b)=>{
    a=U.normText(a); b=U.normText(b);
    const m=a.length,n=b.length;
    if(m===0) return n;
    if(n===0) return m;
    const dp = Array.from({length:m+1},()=>new Array(n+1).fill(0));
    for(let i=0;i<=m;i++) dp[i][0]=i;
    for(let j=0;j<=n;j++) dp[0][j]=j;
    for(let i=1;i<=m;i++){
      const ca=a.charCodeAt(i-1);
      for(let j=1;j<=n;j++){
        const cb=b.charCodeAt(j-1);
        const cost = (ca===cb)?0:1;
        dp[i][j]=Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+cost);
      }
    }
    return dp[m][n];
  };
  U.similarity = (a,b)=>{
    a=U.normText(a); b=U.normText(b);
    const max = Math.max(a.length,b.length);
    if(max===0) return 1;
    const dist = U.levenshtein(a,b);
    return 1 - (dist/max);
  };

  U.downloadText = (filename, text)=>{
    const blob = new Blob([text], {type:'text/plain;charset=utf-8'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
  };

  window.AppUtils = U;
})();