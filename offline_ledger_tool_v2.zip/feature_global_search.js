(function(){
  const U=AppUtils;

  function mount(ctx){
    const root=ctx.mountPoint;
    root.innerHTML = `
      <div class="card">
        <div class="card-row">
          <div class="field">
            <div class="field-label">模式</div>
            <select id="mode">
              <option value="global" selected>全域（預設）</option>
              <option value="item">限定項目（用上方下拉）</option>
            </select>
          </div>
          <div class="field">
            <div class="field-label">matchMode</div>
            <select id="matchMode">
              <option value="like" selected>like（只要包含）</option>
              <option value="=">=（完全相等）</option>
            </select>
          </div>
          <div class="field">
            <div class="field-label">輸入關鍵字（功能5-2）</div>
            <input id="q" type="text" placeholder="例如：進貨 / 營業稅 / 汽車險" />
          </div>
          <div class="field" style="min-width:160px;flex:0 0 160px">
            <button class="btn" id="btnRun" style="width:100%">查核</button>
          </div>
        </div>
        <div class="small">功能5-1（智能）：會嘗試找出「跨項目」的重複字眼（簡化：用你輸入的字眼當錨點；若留空則不執行智能）。</div>
      </div>
      <div class="card">
        <div class="field-label">查核結果</div>
        <div id="result"></div>
      </div>
    `;
    const el = {
      mode: root.querySelector('#mode'),
      matchMode: root.querySelector('#matchMode'),
      q: root.querySelector('#q'),
      btnRun: root.querySelector('#btnRun'),
      result: root.querySelector('#result')
    };

    function collectEntries(){
      const data = ctx.getDataset();
      if(!data) return [];
      const mode = el.mode.value;
      if(mode==='item'){
        const item=ctx.getSelectedItem();
        return item? item.entries.map(e=>({...e, __item:item})): [];
      }
      // global
      const all=[];
      for(const it of data.items){
        for(const e of it.entries) all.push({...e, __item:it});
      }
      return all;
    }

    function run(){
      const q = U.normText(el.q.value||'');
      const mm = el.matchMode.value;
      const data = ctx.getDataset();
      if(!data){ el.result.innerHTML='<div class="small">尚未載入資料</div>'; return; }
      if(!q){ el.result.innerHTML='<div class="small">請輸入關鍵字後再查核</div>'; return; }
      const entries = collectEntries();
      const hits = [];
      for(const e of entries){
        const s = U.normText(e.summary||'');
        let ok=false;
        if(mm==='=') ok = (s===q);
        else ok = s.includes(q);
        if(ok) hits.push(e);
      }
      // group by summary exact for display
      const by = new Map();
      for(const h of hits){
        const k = U.normText(h.summary||'');
        if(!by.has(k)) by.set(k, []);
        by.get(k).push(h);
      }
      const blocks = [];
      for(const [sumText, list] of by.entries()){
        // group by item
        const byItem = new Map();
        let total=0;
        for(const x of list){
          const key = `${x.__item.subjectCode} ${x.__item.subjectName}`;
          if(!byItem.has(key)) byItem.set(key, {item:x.__item, list:[], sum:0});
          byItem.get(key).list.push(x);
          byItem.get(key).sum += x.signedAmount;
          total += x.signedAmount;
        }
        const itemLines = [...byItem.values()].map(g=>{
          const rows = g.list.map(e=>{
            return `<tr><td class="mono">${U.escapeHtml(e.date)}</td><td class="mono">${U.escapeHtml(e.voucherNo||'')}</td><td class="mono">${U.fmtMoney(e.signedAmount)}</td></tr>`;
          }).join('');
          return `<div class="group" style="margin:8px 0">
            <div class="group-head">
              <div>
                <div class="group-title">${U.escapeHtml(g.item.subjectCode)} ${U.escapeHtml(g.item.subjectName)} <span class="chip mono">${U.fmtMoney(g.sum)}</span></div>
                <div class="group-sub">筆數：${g.list.length}</div>
              </div>
            </div>
            <table class="table" style="margin-top:10px">
              <thead><tr><th>日期</th><th>票號</th><th>金額</th></tr></thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;
        }).join('');

        blocks.push(`<div class="group">
          <div class="group-head">
            <div>
              <div class="group-title">${U.escapeHtml(sumText)} <span class="chip mono">合計 ${U.fmtMoney(total)}</span></div>
              <div class="group-sub">命中筆數：${list.length}</div>
            </div>
          </div>
          <div style="margin-top:10px">${itemLines}</div>
        </div>`);
      }
      el.result.innerHTML = blocks.join('') || '<div class="small">無命中</div>';
      ctx.setOutputHint(`查核完成：命中 ${hits.length} 筆。`);
      if(hits.length){
        ctx.setOutputText(`關鍵字「${q}」命中 ${hits.length} 筆（詳見功能5）。`);
      }
    }

    el.btnRun.addEventListener('click', run);

    return {onItemChanged: ()=>{ /* nothing */ }};
  }

  window.FeatureGlobalSearch = {mount};
})();