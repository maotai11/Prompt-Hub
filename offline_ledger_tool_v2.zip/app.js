(function(){
  const U=AppUtils;
  const {S} = AppStorage;

  const state = {
    dataset: null,         // parsed {columnMap, items}
    selectedItemId: null,
    yearFilter: '',
    views: {},
    currentView: 'v1',
    settings: null
  };

  const els = {
    nav: document.getElementById('nav'),
    viewTitle: document.getElementById('viewTitle'),
    viewSubtitle: document.getElementById('viewSubtitle'),
    fileInput: document.getElementById('fileInput'),
    itemSelect: document.getElementById('itemSelect'),
    itemSearch: document.getElementById('itemSearch'),
    yearSelect: document.getElementById('yearSelect'),
    itemSummary: document.getElementById('itemSummary'),
    outputBox: document.getElementById('outputBox'),
    outputHint: document.getElementById('outputHint'),
    btnCopyOut: document.getElementById('btnCopyOut'),
    btnClearOut: document.getElementById('btnClearOut'),
    globalNotice: document.getElementById('globalNotice'),

    // user
    userSelect: document.getElementById('userSelect'),
    btnAddUser: document.getElementById('btnAddUser'),
    btnLogout: document.getElementById('btnLogout'),
    userHint: document.getElementById('userHint')
  };

  function setNotice(msg){
    if(!msg){
      els.globalNotice.style.display='none';
      els.globalNotice.textContent='';
      return;
    }
    els.globalNotice.style.display='block';
    els.globalNotice.textContent=msg;
  }

  function setOutputText(t){ els.outputBox.value = t || ''; }
  function setOutputHint(t){ els.outputHint.textContent = t || ''; }

  function getSelectedItem(){
    if(!state.dataset) return null;
    return state.dataset.items.find(it=>it.id===state.selectedItemId) || null;
  }

  function applyYearFilter(item){
    if(!item) return null;
    if(!state.yearFilter) return item;
    const y = parseInt(state.yearFilter,10);
    const entries = item.entries.filter(e=>e.rocYear===y);
    return {...item, entries, endingBalance: entries.length? entries[entries.length-1].balance : item.endingBalance};
  }

  function refreshItemUI(){
    const itemRaw = getSelectedItem();
    const item = applyYearFilter(itemRaw);

    if(!item){
      els.itemSummary.textContent = state.dataset? '請選擇項目' : '尚未載入資料';
      return;
    }
    const count = item.entries.length;
    const eb = item.endingBalance ?? 0;
    const ob = item.openingBalance?.balance ?? null;
    const dateMin = count? item.entries[0].date : '-';
    const dateMax = count? item.entries[count-1].date : '-';
    els.itemSummary.innerHTML = `
      <div><span class="chip">${U.escapeHtml(item.subjectCode)}</span> <b>${U.escapeHtml(item.subjectName)}</b>（${U.escapeHtml(item.drCr)}）</div>
      <div class="small">筆數：${count}｜期間：${U.escapeHtml(dateMin)} ～ ${U.escapeHtml(dateMax)}｜期末餘額：<span class="mono">${U.fmtMoney(eb)}</span>${ob!=null?`｜上期結轉：<span class="mono">${U.fmtMoney(ob)}</span>`:''}</div>
    `;
  }

  function rebuildItemSelect(){
    const itemSel = els.itemSelect;
    itemSel.innerHTML = '<option value="">請選擇項目…</option>';
    if(!state.dataset) return;
    const q = U.normText(els.itemSearch.value||'');
    const items = state.dataset.items
      .filter(it=>{
        if(!q) return true;
        return (it.subjectCode||'').includes(q) || U.normText(it.subjectName||'').includes(q);
      })
      .slice(0, 500);

    for(const it of items){
      const opt = document.createElement('option');
      opt.value = it.id;
      opt.textContent = `${it.subjectCode} ${it.subjectName} (${it.drCr})`;
      itemSel.appendChild(opt);
    }
    if(state.selectedItemId){
      itemSel.value = state.selectedItemId;
    }
  }

  function rebuildYearSelect(){
    const sel = els.yearSelect;
    sel.innerHTML = '<option value="">全部</option>';
    if(!state.dataset) return;
    const item = getSelectedItem();
    const years = new Set();
    const src = item? item.entries : state.dataset.items.flatMap(it=>it.entries);
    for(const e of src) if(e.rocYear) years.add(e.rocYear);
    [...years].sort((a,b)=>a-b).forEach(y=>{
      const opt=document.createElement('option');
      opt.value=String(y);
      opt.textContent=String(y);
      sel.appendChild(opt);
    });
    sel.value = state.yearFilter || '';
  }

  function mountViews(){
    const ctx = {
      getSelectedItem: ()=> applyYearFilter(getSelectedItem()),
      getDataset: ()=> state.dataset,
      settings: state.settings,
      setOutputText,
      setOutputHint
    };

    state.views.v1 = FeatureGrouping.mount({...ctx, mountPoint: document.getElementById('view_v1')});
    state.views.v2 = FeaturePool.mount({...ctx, mountPoint: document.getElementById('view_v2')});
    state.views.v3 = FeatureAnomaly.mount({...ctx, mountPoint: document.getElementById('view_v3')});
    state.views.v4 = FeatureReconcile.mount({...ctx, mountPoint: document.getElementById('view_v4')});
    state.views.v5 = FeatureGlobalSearch.mount({...ctx, mountPoint: document.getElementById('view_v5')});

    // uploads view
    document.getElementById('view_uploads').innerHTML = `
      <div class="card">
        <div class="field-label">上傳歷史（每位使用者最多 2 份；可刪除）</div>
        <div id="uploadList"></div>
      </div>
    `;
    // settings view
    document.getElementById('view_settings').innerHTML = `
      <div class="card">
        <div class="field-label">忽略規則（可調整；調整後需聯動重算）</div>
        <div class="small">注意：本版本會保存「通用後台設定」到 localStorage（與使用者無關）。</div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:10px">
          <div class="field">
            <div class="field-label">忽略：A 欄精確匹配（每行一個）</div>
            <textarea id="set_exact" rows="6"></textarea>
          </div>
          <div class="field">
            <div class="field-label">忽略：A 欄前綴匹配（每行一個）</div>
            <textarea id="set_prefix" rows="6"></textarea>
          </div>
          <div class="field">
            <div class="field-label">忽略：月計前綴（每行一個）</div>
            <textarea id="set_month" rows="6"></textarea>
          </div>
          <div class="field">
            <div class="field-label">忽略：累計前綴（每行一個）</div>
            <textarea id="set_acc" rows="6"></textarea>
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <button class="btn" id="btnSaveSettings">儲存設定</button>
          <button class="btn btn-ghost" id="btnReparse" disabled>以新設定重算（需先載入資料）</button>
        </div>
      </div>

      <div class="card">
        <div class="field-label">關鍵字庫（全項目通用；唯一歸屬依權重）</div>
        <div class="small">格式：群組名 | 關鍵字 | 權重 | 模式(like/=)；每行一條。例：車險|汽車險|10|like</div>
        <textarea id="set_keywords" rows="10"></textarea>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <button class="btn" id="btnSaveKeywords">儲存關鍵字庫</button>
        </div>
      </div>

      <div class="card">
        <div class="field-label">近似比對門檻</div>
        <div class="card-row">
          <div class="field">
            <div class="field-label">相似度（0.80~1.00）</div>
            <input id="set_sim" type="number" step="0.01" min="0.8" max="1.0"/>
          </div>
        </div>
      </div>
    `;

    hookUploadsView();
    hookSettingsView();
  }

  function viewMeta(view){
    const map = {
      v1:{t:'功能1：關鍵字分組', s:'預覽→確認→可移動/刪除→對齊期末餘額（Diff）'},
      v2:{t:'功能2：數字池', s:'輸入目標數字，在同一項目內找加總組合（去重）'},
      v3:{t:'功能3：異常偵測', s:'離群值（MAD）與摘要近似重複（需確認）'},
      v4:{t:'功能4：沖銷', s:'1v1 優先、確認區、未沖銷再用數字池'},
      v5:{t:'功能5：跨項目關鍵字', s:'全域/限定項目，支援 like/= 模式'},
      uploads:{t:'上傳管理', s:'每位使用者最多保留 2 份；可刪除；可載入分析'},
      settings:{t:'後台設定', s:'忽略規則/關鍵字庫/相似度；調整後可重算'}
    };
    return map[view]||map.v1;
  }

  function switchView(view){
    state.currentView=view;
    document.querySelectorAll('.view').forEach(v=>v.style.display='none');
    const id = 'view_'+view;
    const box = document.getElementById(id);
    if(box) box.style.display='block';

    document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));
    const btn = document.querySelector(`.nav-item[data-view="${view}"]`);
    if(btn) btn.classList.add('active');

    const meta = viewMeta(view);
    els.viewTitle.textContent = meta.t;
    els.viewSubtitle.textContent = meta.s;
  }

  function hookNav(){
    els.nav.querySelectorAll('.nav-item').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        switchView(btn.getAttribute('data-view'));
      });
    });
  }

  function hookOutput(){
    els.btnCopyOut.addEventListener('click', async ()=>{
      try{
        await navigator.clipboard.writeText(els.outputBox.value||'');
        setOutputHint('已複製到剪貼簿。');
      }catch(e){
        // fallback
        els.outputBox.select();
        document.execCommand('copy');
        setOutputHint('已複製到剪貼簿（fallback）。');
      }
    });
    els.btnClearOut.addEventListener('click', ()=>{
      els.outputBox.value='';
      setOutputHint('已清空輸出。');
    });
  }

  function hookItemSelectors(){
    els.itemSearch.addEventListener('input', rebuildItemSelect);
    els.itemSelect.addEventListener('change', ()=>{
      state.selectedItemId = els.itemSelect.value || null;
      rebuildYearSelect();
      refreshItemUI();
      // notify views
      Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(applyYearFilter(getSelectedItem())));
    });
    els.yearSelect.addEventListener('change', ()=>{
      state.yearFilter = els.yearSelect.value || '';
      refreshItemUI();
      Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(applyYearFilter(getSelectedItem())));
    });
  }

  async function loadSettings(){
    S.ensureVersion();
    let st = S.getGlobalSettings();
    if(!st){
      st = S.defaultSettings();
      S.setGlobalSettings(st);
    }
    state.settings = st;
  }

  function parseKeywordTextToLib(text){
    const lines = text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
    const by = new Map();
    for(const line of lines){
      const parts = line.split('|').map(x=>x.trim());
      if(parts.length<2) continue;
      const g=parts[0]||'未命名';
      const k=parts[1]||'';
      const w=Number(parts[2]||0);
      const mode=(parts[3]||'like').toLowerCase()==='='?'=':'like';
      if(!by.has(g)) by.set(g, []);
      by.get(g).push({text:k, weight:w, mode});
    }
    return [...by.entries()].map(([name, keywords])=>({name, keywords}));
  }

  function libToKeywordText(lib){
    const lines=[];
    for(const g of (lib||[])){
      for(const k of (g.keywords||[])){
        lines.push([g.name, k.text, k.weight??0, k.mode||'like'].join('|'));
      }
    }
    return lines.join('\n');
  }

  function hookSettingsView(){
    const exact = document.getElementById('set_exact');
    const prefix = document.getElementById('set_prefix');
    const month = document.getElementById('set_month');
    const acc = document.getElementById('set_acc');
    const sim = document.getElementById('set_sim');
    const kw = document.getElementById('set_keywords');
    const btnSave = document.getElementById('btnSaveSettings');
    const btnReparse = document.getElementById('btnReparse');
    const btnSaveKw = document.getElementById('btnSaveKeywords');

    const st = state.settings;
    exact.value = (st.ignore.exactAColumnLines||[]).join('\n');
    prefix.value = (st.ignore.startsWithAColumn||[]).join('\n');
    month.value = (st.ignore.ignoreMonthTotalPrefix||[]).join('\n');
    acc.value = (st.ignore.ignoreAccumTotalPrefix||[]).join('\n');
    sim.value = String(st.matching.similarityThreshold||0.85);
    kw.value = libToKeywordText(st.keywordGroups||[]);

    btnReparse.disabled = !state.dataset;

    btnSave.addEventListener('click', ()=>{
      state.settings.ignore.exactAColumnLines = exact.value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      state.settings.ignore.startsWithAColumn = prefix.value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      state.settings.ignore.ignoreMonthTotalPrefix = month.value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      state.settings.ignore.ignoreAccumTotalPrefix = acc.value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      state.settings.matching.similarityThreshold = Math.min(1, Math.max(0.8, Number(sim.value||0.85)));
      S.setGlobalSettings(state.settings);
      setOutputHint('已儲存後台設定。');
      btnReparse.disabled = !state.dataset;
    });

    btnSaveKw.addEventListener('click', ()=>{
      state.settings.keywordGroups = parseKeywordTextToLib(kw.value);
      S.setGlobalSettings(state.settings);
      setOutputHint('已儲存關鍵字庫。');
    });

    btnReparse.addEventListener('click', async ()=>{
      // reparse from latest upload data in memory if exists
      const currentUserId = S.getCurrentUserId();
      if(!currentUserId) return;
      const latest = await S.loadLatestUpload(currentUserId);
      if(!latest?.data?.rows){
        setOutputHint('找不到可重算的 rows（請重新上傳）。');
        return;
      }
      const parsed = AppParser.parseRowsToItems(latest.data.rows, state.settings);
      state.dataset = parsed;
      state.selectedItemId = null;
      rebuildItemSelect(); rebuildYearSelect(); refreshItemUI();
      Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(null));
      setOutputHint('已依新忽略規則重算（你需要重新選擇項目）。');
    });
  }

  async function hookUploadsView(){
    const box = document.getElementById('uploadList');
    const userId = S.getCurrentUserId();
    if(!userId){
      box.innerHTML = '<div class="small">請先新增/登入使用者</div>';
      return;
    }
    const idx = S.getUserUploadIndex(userId).sort((a,b)=>b.ts-a.ts);
    if(!idx.length){
      box.innerHTML = '<div class="small">尚無上傳歷史（每位使用者最多 2 份）</div>';
      return;
    }
    box.innerHTML = idx.map(meta=>{
      const dt = new Date(meta.ts);
      const label = `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')} ${String(dt.getHours()).padStart(2,'0')}:${String(dt.getMinutes()).padStart(2,'0')}`;
      return `<div class="group">
        <div class="group-head">
          <div>
            <div class="group-title">${U.escapeHtml(meta.name)} <span class="chip">${label}</span></div>
            <div class="group-sub">ID：${U.escapeHtml(meta.id)}</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn" data-load="${U.escapeHtml(meta.id)}">載入</button>
            <button class="btn btn-ghost" data-del="${U.escapeHtml(meta.id)}">刪除</button>
          </div>
        </div>
      </div>`;
    }).join('');

    box.querySelectorAll('[data-load]').forEach(btn=>{
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-load');
        const data = await S.loadUpload(userId, id);
        if(!data){ setNotice('載入失敗：找不到資料'); return; }
        state.dataset = data.parsed;
        state.selectedItemId = null;
        rebuildItemSelect(); rebuildYearSelect(); refreshItemUI();
        Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(null));
        setNotice('');
        setOutputHint('已載入上傳歷史，請選擇項目開始分析。');
        switchView('v1');
      });
    });

    box.querySelectorAll('[data-del]').forEach(btn=>{
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-del');
        await S.deleteUpload(userId, id);
        setOutputHint('已刪除上傳紀錄。');
        hookUploadsView();
      });
    });
  }

  async function onFileSelected(file){
    const userId = S.getCurrentUserId();
    if(!userId){
      setNotice('請先新增/登入使用者，才能上傳檔案。');
      return;
    }
    setNotice('');
    try{
      const rows = await AppParser.readFileToRows(file);
      const parsed = AppParser.parseRowsToItems(rows, state.settings);

      // Save: only store parsed + rows for reparse; no raw file bytes
      const payload = {rows, parsed};
      await S.saveUploadForUser(userId, file.name, payload);

      // load into memory
      state.dataset = parsed;
      state.selectedItemId = null;
      rebuildItemSelect();
      rebuildYearSelect();
      refreshItemUI();
      Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(null));

      setOutputHint(`已解析：共 ${parsed.items.length} 個項目。請選擇項目開始分析。`);
    }catch(e){
      console.error(e);
      setNotice('解析失敗：' + (e?.message || e));
    }
  }

  function hookFile(){
    els.fileInput.addEventListener('change', async ()=>{
      const f = els.fileInput.files && els.fileInput.files[0];
      if(!f) return;
      await onFileSelected(f);
      els.fileInput.value = '';
      // refresh uploads tab list
      if(state.currentView==='uploads') hookUploadsView();
    });
  }

  function refreshUsersUI(){
    const users = S.listUsers();
    els.userSelect.innerHTML = '';
    for(const u of users){
      const opt=document.createElement('option');
      opt.value=u.id; opt.textContent=u.name;
      els.userSelect.appendChild(opt);
    }
    const cur = S.getCurrentUserId();
    if(cur && users.some(u=>u.id===cur)) els.userSelect.value=cur;
    els.userHint.textContent = users.length? '可隨時切換使用者；登出不會清除紀錄。' : '尚無使用者。請新增/登入。';
  }

  function hookUsers(){
    refreshUsersUI();

    els.btnAddUser.addEventListener('click', ()=>{
      const name = prompt('輸入使用者名稱（本地保存，可隨時切換）：');
      if(!name) return;
      const u = S.addUser(name);
      refreshUsersUI();
      // load latest upload for that user automatically
      loadUserLatest();
    });

    els.userSelect.addEventListener('change', ()=>{
      const id = els.userSelect.value;
      S.setCurrentUserId(id);
      loadUserLatest();
      if(state.currentView==='uploads') hookUploadsView();
    });

    els.btnLogout.addEventListener('click', ()=>{
      S.logout();
      setOutputHint('已登出（本地資料仍保留，可隨時切換）。');
    });
  }

  async function loadUserLatest(){
    const userId = S.getCurrentUserId();
    if(!userId){
      state.dataset=null;
      rebuildItemSelect(); rebuildYearSelect(); refreshItemUI();
      return;
    }
    const latest = await S.loadLatestUpload(userId);
    if(latest?.data?.parsed){
      state.dataset = latest.data.parsed;
      state.selectedItemId = null;
      rebuildItemSelect(); rebuildYearSelect(); refreshItemUI();
      Object.values(state.views).forEach(v=>v.onItemChanged && v.onItemChanged(null));
      setOutputHint('已載入此使用者最近一次上傳紀錄。');
    }else{
      state.dataset=null;
      rebuildItemSelect(); rebuildYearSelect(); refreshItemUI();
      setOutputHint('此使用者尚無上傳紀錄。');
    }
  }

  async function init(){
    await loadSettings();
    mountViews();
    hookNav();
    hookOutput();
    hookItemSelectors();
    hookFile();
    hookUsers();

    await loadUserLatest();
    switchView('v1');

    // If xlsx lib missing, warn
    if(typeof XLSX === 'undefined'){
      setNotice('注意：尚未載入 xlsx.full.min.js。請把本地 xlsx.full.min.js 放在同一資料夾（覆蓋占位檔），再重新開啟。');
    }
  }

  init();
})();