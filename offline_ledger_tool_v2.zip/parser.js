(function(){
  const U = AppUtils;
  const {S} = AppStorage;

  function detectColumnMap(rows){
    // rows: array of arrays (cell values)
    // find first row that contains key headers
    const targets = ["日期","摘要","借方金額","貸方金額","借/貸","餘額","傳票號碼"];
    for(let r=0;r<rows.length;r++){
      const row = rows[r].map(v=>U.normText(v));
      const hit = targets.filter(t=> row.includes(t));
      if(hit.length>=5){
        const map = {};
        for(let c=0;c<row.length;c++){
          const v=row[c];
          if(v==="日期") map.date=c;
          if(v==="傳票號碼") map.voucher=c;
          if(v==="摘要") map.summary=c;
          if(v==="借方金額") map.debit=c;
          if(v==="貸方金額") map.credit=c;
          if(v==="借/貸") map.drcr=c;
          if(v==="餘額") map.balance=c;
        }
        return {headerRowIndex:r, map};
      }
    }
    // fallback: typical columns from your file
    return {headerRowIndex:0, map:{date:0,voucher:4,summary:11,debit:14,credit:17,drcr:19,balance:21}};
  }

  function shouldIgnoreRow(row, settings, state){
    // state: {seenHeader:boolean}
    const a = U.normText(row[0] ?? "");
    if(!a) return {ignore:false, reason:null};
    // ignore company/header lines (page headers)
    if(settings.ignore.exactAColumnLines.map(U.normText).includes(a)) return {ignore:true, reason:"pageHeaderExact"};
    if(settings.ignore.startsWithAColumn.some(p=> a.startsWith(U.normText(p)))) return {ignore:true, reason:"pageHeaderStarts"};
    // ignore repeated table header rows after first header
    if(state && state.seenHeader){
      const maybeHeader = ["日期","摘要","借方金額","貸方金額","借/貸","餘額"].every(h=>{
        return row.some(cell=>U.normText(cell)===h);
      });
      if(maybeHeader) return {ignore:true, reason:"repeatedTableHeader"};
    }
    // month/acc totals
    if(settings.ignore.ignoreMonthTotalPrefix.some(p=>a.startsWith(U.normText(p)))) return {ignore:true, reason:"monthTotal"};
    if(settings.ignore.ignoreAccumTotalPrefix.some(p=>a.startsWith(U.normText(p)))) return {ignore:true, reason:"accTotal"};
    return {ignore:false, reason:null};
  }

  function parseItemLine(aText){
    // Example: "項  目:1245 預付保險費(借) ..."
    const t = U.normText(aText);
    const m = t.match(/項\s*目\s*:\s*(\d+)\s*([^\(]+)\((借|貸)\)/);
    if(!m) return null;
    return {subjectCode:m[1], subjectName:U.trim(m[2]), drCr:m[3]};
  }

  function parseRowsToItems(rows, settings){
    const {headerRowIndex, map} = detectColumnMap(rows);
    const state = {seenHeader:false};

    const items = [];
    let current = null;

    function ensureItem(meta){
      if(current && current.subjectCode === meta.subjectCode){
        // cross-page same subject -> continue
        return current;
      }
      current = {
        id: meta.subjectCode,
        subjectCode: meta.subjectCode,
        subjectName: meta.subjectName,
        drCr: meta.drCr,
        openingBalance: null,
        entries: [],
        endingBalance: null
      };
      items.push(current);
      return current;
    }

    for(let i=0;i<rows.length;i++){
      const row = rows[i];

      // detect header row once
      if(i===headerRowIndex){
        state.seenHeader=true;
        continue;
      }

      const ign = shouldIgnoreRow(row, settings, state);
      if(ign.ignore) continue;

      const a = U.normText(row[0] ?? "");
      // item start
      if(a.startsWith("項")){
        const meta = parseItemLine(a);
        if(meta) ensureItem(meta);
        continue;
      }

      if(!current) continue;

      // opening balance
      if(a==="上期結轉"){
        // balance stored in map.balance or near; in your file, balance is at map.balance and extra zeros after
        const bal = U.parseMoney(row[map.balance]);
        current.openingBalance = {label:"上期結轉", balance: bal};
        continue;
      }

      // detail row by date
      if(U.isDateROC(a)){
        const dateObj = U.parseROC(a);
        const voucher = U.normText(row[map.voucher] ?? "");
        // some files put '@' at another column; keep it inside summary if present
        let summary = U.normText(row[map.summary] ?? "");
        // if there's a standalone '@' before summary (like col J), merge
        const maybeAt = row.find(v=>U.normText(v)==='@');
        if(maybeAt && !summary.startsWith('@')) summary = '@ ' + summary;

        const rawDebit = U.parseMoney(row[map.debit]);
        const rawCredit = U.parseMoney(row[map.credit]);
        const drcrCell = U.normText(row[map.drcr] ?? "") || current.drCr;

        // heuristic: if only one side has value but column mapping is shifted, use drcrCell to decide
        let debit = rawDebit, credit = rawCredit;
        if(debit===0 && credit!==0 && drcrCell.startsWith('借')){ debit = credit; credit = 0; }
        if(credit===0 && debit!==0 && drcrCell.startsWith('貸')){ credit = debit; debit = 0; }

        const balance = U.parseMoney(row[map.balance]);
        const entry = {
          date: dateObj.iso,
          rocYear: dateObj.rocYear,
          month: dateObj.month,
          voucherNo: voucher,
          summary,
          debit,
          credit,
          balance,
          drcr: drcrCell.startsWith('借')?'借':'貸'
        };

        // signedAmount per item drCr
        let signed = 0;
        if(current.drCr === '借'){
          signed = debit>0 ? debit : -credit;
        }else{
          signed = credit>0 ? credit : -debit;
        }
        entry.signedAmount = signed;

        // key for dedup
        entry.entryKey = [
          entry.date, entry.voucherNo, U.normText(entry.summary),
          entry.debit, entry.credit, entry.balance
        ].join('|');

        current.entries.push(entry);
        current.endingBalance = balance; // last detail's balance
        continue;
      }
    }

    // finalize ending balance: must be last detail row balance
    for(const it of items){
      if(it.entries.length){
        it.endingBalance = it.entries[it.entries.length-1].balance;
      }
    }
    return {columnMap: map, headerRowIndex, items};
  }

  async function readFileToRows(file){
    const name = file.name || '';
    const ext = name.split('.').pop().toLowerCase();
    if(ext==='csv'){
      const text = await file.text();
      // detect delimiter , or tab
      const delim = text.includes('\t') ? '\t' : ',';
      const lines = text.split(/\r?\n/).filter(x=>x.trim().length>0);
      return lines.map(line=> line.split(delim));
    }
    // xlsx/xls
    if(typeof XLSX === 'undefined'){
      throw new Error('缺少 xlsx.full.min.js：請把本地 xlsx.full.min.js 放在同一資料夾。');
    }
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, {type:'array'});
    const sheetName = wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    // sheet_to_json with header:1 gives array-of-arrays
    const rows = XLSX.utils.sheet_to_json(ws, {header:1, raw:true, defval:null});
    return rows;
  }

  window.AppParser = {detectColumnMap, parseRowsToItems, readFileToRows};
})();